# OpenDuck Mini V3 ENHANCED - Procurement Guide

**Date**: 2026-01-11
**Status**: ✅ Ready for Procurement
**Excel File**: `OpenDuck_Mini_V3_ENHANCED_BOM.xlsx`

---

## 🎯 Project Overview

### What You're Building
**OpenDuck Mini V3 ENHANCED** - Custom upgraded version with:
- ✅ **Base Robot**: 42cm bipedal walking robot (Official V2 design)
- 👁️ **Computer Vision Eyes**: Raspberry Pi AI Camera (IMX500) with on-sensor AI
- 🦾 **Functional 2DOF Arms**: Metal gripper for object manipulation
- 🎨 **Creative Aesthetics**: Rainbow/gradient filaments for unique look

### Key Enhancements Over Standard V2
1. **Computer Vision Package** (+€83): AI camera, flex cable, acrylic eye lenses
2. **2DOF Arms Package** (+€51): Metal gripper kit, 4x MG90S servos, extensions
3. **Creative Filaments**: Rainbow/gradient PLA for automatic color transitions

---

## 💰 Total Cost Breakdown

### Configuration Summary

| Configuration | Total EUR | What's Included |
|--------------|-----------|-----------------|
| **Base Robot (V2 Standard)** | €1,020-1,096 | All official V2 components + QIDI printer |
| **+ Computer Vision** | €1,103-1,179 | + AI Camera eyes |
| **+ 2DOF Arms** | €1,154-1,230 | + Vision + Arms |
| **+ Tools (if needed)** | €1,229-1,305 | + Vision + Arms + All tools |

### Already Purchased ✅
- **QIDI X-Max 3 Printer**: €599 (PAID)

### To Purchase
- **Electronics & Servos**: €350-400
- **Computer Vision ADD-ON**: €83
- **2DOF Arms ADD-ON**: €51
- **Filaments & Hardware**: €80-120
- **Tools (Optional)**: €75

---

## 📊 Excel File Structure

The Excel file contains **3 comprehensive sheets**:

### Sheet 1: SUMMARY
- Quick cost overview
- Status tracking (✅ Purchased vs ⬜ To Buy)
- Total with/without tools
- Key features list

### Sheet 2: COMPLETE_BOM
**11 organized categories** with 37 components:

1. **Hardware Already Purchased** (✅ €599)
   - QIDI X-Max 3 printer

2. **Compute & Control** (€50)
   - Raspberry Pi Zero 2W
   - MicroSD 64GB
   - Servo control board

3. **Power System** (€66)
   - 2x Molicel 18650 batteries
   - BMS, UBEC, charger
   - 🔥 LiPo fireproof bag (MANDATORY)

4. **Servos (Legs)** (€252-308) ⚠️ **MOST EXPENSIVE**
   - 14x Feetech STS3215 (7.4V, 19kg·cm)
   - 2x 9g servos

5. **Sensors & I/O** (€38)
   - BNO055 IMU
   - 4x limit switches

6. **Computer Vision ADD-ON** (€83) 👁️ **CUSTOM**
   - Raspberry Pi AI Camera (IMX500) - €70
   - Camera flex cable - €5
   - Acrylic eye lenses 20mm (2pcs) - €8

7. **Braccia 2DOF ADD-ON** (€51) 🦾 **CUSTOM**
   - 2DOF metal gripper arm kit - €25
   - 4x MG90S metal gear servos - €18
   - Servo extension cables - €8

8. **Hardware Meccanico** (€28)
   - M3 heat-set inserts
   - M2/M3 screw assortment
   - 608ZZ bearings

9. **Filamenti Base** (€52)
   - 2kg PLA white
   - 250g TPU

10. **Cavi & Connettori** (€39)
    - Dupont cables, silicone wire, heat shrink, etc.

11. **Tools (Optional)** (€75)
    - Soldering iron, cutters, multimeter, calipers, etc.

### Sheet 3: FILAMENTS_CREATIVE
**8 creative filament options** with:
- Rainbow PLA/PETG varieties
- Gradient/Silk finishes
- Matte/Glossy options
- Price range: €20-26/kg
- Direct Amazon.it links

**Top Recommendations**:
1. 🥇 **SUNLU Rainbow PLA+** (€23) - Best value, vibrant colors
2. 🥈 **SUNLU Silk Rainbow** (€25) - Premium glossy finish
3. 🥉 **Sovol Matte Rainbow** (€22) - Modern matte aesthetic

---

## 🛒 Procurement Strategy

### Order Priority & Timeline

#### 📦 Order 1: IMMEDIATE (Amazon.it) - €250-300
**Ship within 2-3 days**

Critical items:
- 🔥 LiPo fireproof bag (€10) **ORDER FIRST**
- Power components (€66)
- Hardware & cables (€67)
- Filaments base (€52)
- Tools if needed (€75)

**Amazon.it Total**: ~€250-300
**Link**: https://www.amazon.it

---

#### 📦 Order 2: SPECIALIZED EU (Week 1) - €150-180
**Ship within 3-7 days**

**Melopero.com** (Italy):
- Raspberry Pi Zero 2W (€26)
- BNO055 IMU (€32)
- Raspberry Pi AI Camera IMX500 (€70)
- MicroSD 64GB (€12)

**NKON.nl** (Netherlands):
- 2x Molicel 18650 P30B (€14)

**Total**: ~€150-180
**Shipping**: €8-15

---

#### 📦 Order 3: SERVOS (Week 1-2) - €270-320
**Ship within 15-30 days** ⚠️ ORDER EARLY

**AliExpress**:
- 14x Feetech STS3215 servos (€252-308)
- Servo control board (€12)

**⚠️ CRITICAL**:
- Verify stock availability BEFORE ordering other items
- Check AliExpress seller rating (>95%, >1000 orders)
- Confirm 7.4V version (NOT 6V)
- Alternative: Waveshare ST3215-HS (€20-24 ea)

---

#### 📦 Order 4: ARMS & VISION (Week 2) - €134
**Ship within 5-10 days**

**For Computer Vision**:
- Camera flex cable (€5) - Amazon.it
- Acrylic eye lenses (€8) - AliExpress

**For 2DOF Arms**:
- 2DOF metal gripper kit (€25) - Amazon.com
- 4x MG90S servos (€18) - Amazon.it
- Servo extensions (€8) - Amazon.it

---

#### 🎨 Order 5: CREATIVE FILAMENTS (Week 2-3) - €60-80
**Optional - Order when ready to print**

**Recommendations**:
- 2x SUNLU Rainbow PLA+ (€46) - Main body
- 1x Sovol Matte Rainbow (€22) - Accent parts
- 1x SUNLU Rainbow PETG (€26) - Drone frames (future)

**All available on Amazon.it** with Prime shipping

---

## ⚠️ CRITICAL PRE-PURCHASE CHECKLIST

### Before Spending ANY Money:

#### ✅ 1. Verify Servo Availability (BLOCKING)
```
Check AliExpress for Feetech STS3215:
- Price: €18-22 each (€252-308 total for 14)
- Stock: "In Stock" and ships to Italy
- Seller rating: >95%, >1000 orders
- Delivery: 15-30 days acceptable?

IF NOT AVAILABLE:
- Alternative 1: Waveshare ST3215-HS (€20-24 ea)
- Alternative 2: Wait for restock
- DO NOT ORDER other items until servo source confirmed
```

#### ✅ 2. Confirm Budget
```
Your total budget: €_________

Minimum (no arms, no vision): €1,020-1,096
With vision only: €1,103-1,179
Full build (vision + arms): €1,154-1,230
With tools: €1,229-1,305

Can you afford the full configuration? YES / NO
```

#### ✅ 3. Join Discord (REQUIRED)
```
Discord: https://discord.gg/UtJZsgfQGe

Ask BEFORE ordering:
1. "What's the largest STL dimension in V2?"
   → Verify 325x325mm QIDI bed is sufficient
2. "Anyone integrated custom arms successfully?"
   → Get community advice
3. "Best servo source in EU right now?"
   → Get current recommendations
```

#### ✅ 4. Time Commitment Check
```
Total estimated time:
- Parts procurement: 3-4 weeks
- 3D printing: 60-80 hours (8-10 days @ 8h/day)
- Assembly: 30-40 hours (4-5 days)
- Software setup: 15-20 hours (2-3 days)
- Vision integration: 10-15 hours (2 days)
- Arms integration: 15-20 hours (2-3 days)

TOTAL: 14-18 weeks for full build

Can you commit this time? YES / NO
```

---

## 🔧 Technical Specifications

### Computer Vision System (Custom Addition)

**Hardware**:
- **Camera**: Raspberry Pi AI Camera (IMX500)
  - 12MP Sony sensor
  - On-sensor AI processing
  - Real-time object detection
  - Pose estimation capable
  - No CPU load (runs on camera)

**Integration**:
- Mount in robot head
- 15cm flex cable to Pi Zero 2W
- Acrylic dome lenses for "eyes" effect
- Power: 5V from UBEC (shared with Pi)

**Software** (to implement):
- OpenCV for basic vision
- IMX500 SDK for on-sensor AI
- YOLO for object detection
- Face tracking algorithms

---

### 2DOF Arms System (Custom Addition)

**Hardware**:
- **Gripper**: 2DOF aluminium kit
  - Shoulder joint: 1 DOF (MG90S)
  - Gripper: 1 DOF (MG90S)
  - Reach: ~15cm
  - Payload: ~50g

**Servos**:
- 4x MG90S metal gear servos
  - Torque: 2.2 kg·cm @ 6V
  - Speed: 0.11 sec/60°
  - Metal gears (durable)

**Integration**:
- Mount to body sides
- Extend servo control board (16 channels available)
- Power: 5V from UBEC
- Control: PWM via Raspberry Pi GPIO

**Capability**:
- Pick up small objects (<50g)
- Point/gesture
- Hold sensors
- Basic manipulation tasks

---

### Filament Requirements

#### Structural Parts (PLA White)
- Body shell: ~600g
- Leg components: ~800g
- Feet: ~200g
- **Total needed**: 1.6kg → **Order 2kg** (includes reprints buffer)

#### Flexible Parts (TPU 95A)
- Foot pads: ~50g
- Cable management: ~30g
- Grommets: ~20g
- **Total needed**: 100g → **Order 250g**

#### Creative Parts (Rainbow PLA+)
- Head/eyes housing: ~150g
- Arm covers: ~100g
- Decorative panels: ~200g
- **Total needed**: 450g → **Order 1kg** (2x rainbow spools recommended)

---

## 🎨 Aesthetic Customization Ideas

### Rainbow Filament Usage Strategies

**Option 1: Full Rainbow Body** (Most Dramatic)
- Print entire body in SUNLU Rainbow PLA+
- Automatic color transitions as layers print
- No manual filament swaps needed
- Best for: Show pieces, desk display

**Option 2: Accent Rainbow** (Balanced)
- White PLA for structure (legs, body frame)
- Rainbow for visible panels (head, chest, arms)
- Professional look with creative flair
- Best for: Daily use, demonstrations

**Option 3: Dual-Color Vision** (Advanced)
- White PLA for main body
- Silk Rainbow for head/eyes (premium look)
- Matte Rainbow for arms (contrast)
- Best for: Photography, competitions

### Color Change Patterns

**SUNLU Rainbow PLA+**:
- Changes every 8 meters
- Pattern: Red → Cyan → Blue → Purple → (repeat)
- ~330m total per spool
- ~41 color cycles per kg

**Effect on Prints**:
- Small parts: 1-2 colors
- Medium parts (10-20cm): 3-4 colors
- Large parts (>20cm): 5+ colors (full gradient)

---

## 📚 Essential Resources

### Official Documentation
- **GitHub**: https://github.com/apirrone/Open_Duck_Mini
- **BOM (Google Sheets)**: https://docs.google.com/spreadsheets/d/1gq4iWWHEJVgAA_eemkTEsshXqrYlFxXAPwO515KpCJc/edit
- **CAD (OnShape)**: https://cad.onshape.com/documents/64074dfcfa379b37d8a47762
- **Discord**: https://discord.gg/UtJZsgfQGe ← **JOIN THIS FIRST**

### Computer Vision References
- **Raspberry Pi AI Camera**: https://www.raspberrypi.com/products/ai-camera/
- **IMX500 SDK**: https://www.raspberrypi.com/documentation/accessories/ai-camera.html
- **OpenCV Robotics**: https://opencv.org/
- **YOLO Object Detection**: https://github.com/ultralytics/yolov5

### Robot Arms Tutorials
- **2DOF Gripper Guide**: https://howtomechatronics.com/tutorials/arduino/diy-arduino-robot-arm-with-smartphone-control/
- **Inverse Kinematics**: https://www.youtube.com/watch?v=T_cGUxPU_Xo
- **Servo Control Python**: https://github.com/adafruit/Adafruit_CircuitPython_ServoKit

### Filament Reviews
- **Best Rainbow Filaments 2025**: https://all3dp.com/2/rainbow-filament-pla-brands-compared/
- **Multicolor Guide**: https://3dbeginnerzone.com/gear-guides/best-multicolor-filament/
- **SUNLU Official**: https://store.sunlu.com/

---

## 🚨 Safety & Risk Mitigation

### LiPo Battery Safety (CRITICAL)
⚠️ **18650 cells can catch fire if mishandled**

**Mandatory precautions**:
- ✅ Use fireproof charging bag (€10) - **NON-NEGOTIABLE**
- ✅ Never charge unattended
- ✅ Check BMS connections before first power-on
- ✅ Inspect cells for damage (dents, tears)
- ✅ Balance charge with proper charger

**Warning signs**:
- 🔥 Heat during charging/use
- 🔥 Swelling/puffing
- 🔥 Unusual odor
- → **STOP USE IMMEDIATELY**, place in fireproof container

---

### Servo Torque Safety

**STS3215 servos are STRONG** (19 kg·cm):
- Can cause injury if hand caught
- Can break 3D printed parts under full torque
- Use software torque limiting during testing

**Best practices**:
- Test servos individually before assembly
- Implement software emergency stop
- Never power servos while holding robot
- Add mechanical stops to prevent over-rotation

---

### Print Quality Requirements

**Critical parts** (require high quality):
- Servo mounts: 100% infill, 0.2mm layers
- Foot contact points: 80% infill, TPU
- Load-bearing joints: PLA+, annealed

**Aesthetic parts** (can be lower quality):
- Body panels: 20% infill OK
- Covers: 15% infill OK
- Rainbow parts: Print slow (40mm/s) for clean gradients

---

## 🏁 Next Steps - Action Plan

### Week 1: Planning & First Orders
- [ ] Join Discord: https://discord.gg/UtJZsgfQGe
- [ ] Verify servo availability on AliExpress
- [ ] Ask Discord about STL dimensions
- [ ] **ORDER 1**: Amazon.it components (€250-300)
- [ ] **ORDER 2**: Melopero + NKON (€150-180)
- [ ] **ORDER 3**: AliExpress servos (€270-320)

### Week 2: Printer Setup
- [ ] QIDI X-Max 3 calibration
- [ ] First test print (calibration cube)
- [ ] Tune for PLA (recommended: 210°C, 60°C bed)
- [ ] **ORDER 4**: Arms & Vision components (€134)

### Week 3-4: Main Printing Phase
- [ ] Print all body parts (white PLA)
- [ ] Print leg components
- [ ] Print feet (TPU)
- [ ] **ORDER 5**: Creative filaments (€60-80)

### Week 5: Creative Parts
- [ ] Print head/eyes in Rainbow PLA+
- [ ] Print arm covers
- [ ] Print decorative panels

### Week 6-7: Assembly
- [ ] Assemble legs with servos
- [ ] Install power system (BMS, UBEC)
- [ ] Wire servo control board
- [ ] Mount Raspberry Pi Zero 2W

### Week 8: Software Setup
- [ ] Flash OpenDuck OS to SD card
- [ ] Install servo control software
- [ ] Calibrate all 14 servos
- [ ] Test basic walking gait

### Week 9-10: Vision Integration
- [ ] Install AI Camera in head
- [ ] Configure IMX500 SDK
- [ ] Test object detection
- [ ] Implement eye-tracking

### Week 11-12: Arms Integration
- [ ] Assemble 2DOF gripper
- [ ] Mount arms to body
- [ ] Extend servo control
- [ ] Test pick-and-place

### Week 13-14: Final Integration & Testing
- [ ] Full system integration test
- [ ] Walking + vision + arms coordination
- [ ] Debugging and refinement
- [ ] Documentation and showcase!

---

## 💬 Support & Community

### Need Help?

1. **Discord** (FASTEST): https://discord.gg/UtJZsgfQGe
   - Active community
   - Real builders with experience
   - Quick responses (usually <2 hours)

2. **GitHub Issues**: https://github.com/apirrone/Open_Duck_Mini/issues
   - For bugs or feature requests
   - Search closed issues first

3. **Reddit**: r/robotics, r/3Dprinting
   - General robotics help
   - Print quality troubleshooting

---

## 📝 Excel File Usage Tips

### How to Use the Excel File

1. **Open in Excel/LibreOffice**
   - All formulas will auto-calculate
   - Green cells = already purchased
   - White cells = to buy

2. **Track Your Orders**
   - Add a "Status" column
   - Mark items: "Ordered", "Shipped", "Received"
   - Add order numbers for tracking

3. **Budget Adjustments**
   - Prices are estimates (January 2026)
   - Update with actual prices as you order
   - Totals will recalculate automatically

4. **Links Are Clickable**
   - Ctrl+Click to open purchase links
   - Some links are search URLs (find best current price)

5. **Print for Workshop**
   - Print COMPLETE_BOM sheet
   - Check off items as you receive them
   - Note any issues in "Notes" column

---

## ✅ Final Checklist Before First Order

- [ ] I have €1,200-1,300 budget allocated
- [ ] I joined the Discord server
- [ ] I verified servo availability (STS3215)
- [ ] I confirmed QIDI X-Max 3 bed size is adequate
- [ ] I have LiPo fireproof bag in cart (SAFETY)
- [ ] I understand total timeline is 12-16 weeks
- [ ] I have basic electronics skills (soldering, wiring)
- [ ] I have a computer for programming Raspberry Pi
- [ ] I'm committed to this advanced project
- [ ] I've read all safety warnings

**If ALL boxes checked** → **PROCEED WITH ORDERS** ✅
**If ANY unchecked** → **RESOLVE FIRST** ❌

---

## 🎯 Success Metrics

### What "Success" Looks Like

**Phase 1: Walking Robot** (Week 8)
- ✅ Robot stands and balances
- ✅ Walks forward/backward smoothly
- ✅ Turns left/right
- ✅ No servo errors or overheating

**Phase 2: Vision System** (Week 10)
- ✅ Camera detects objects in real-time
- ✅ Face tracking works
- ✅ No CPU overload (thanks to IMX500)
- ✅ Eyes light up with LEDs (optional)

**Phase 3: Functional Arms** (Week 12)
- ✅ Arms move independently
- ✅ Gripper opens/closes reliably
- ✅ Can pick up 30-50g objects
- ✅ Coordinated with walking

**Phase 4: Full Integration** (Week 14)
- ✅ Walk + vision + manipulation together
- ✅ Can navigate around obstacles (vision)
- ✅ Can pick up detected objects (arms)
- ✅ Autonomous behavior loops

---

## 🚀 You're Ready!

**You now have everything needed to build:**
- ✅ Complete BOM in Excel format
- ✅ Detailed procurement strategy
- ✅ EU purchase links (Amazon.it, Melopero, AliExpress)
- ✅ Computer vision enhancement package
- ✅ 2DOF functional arms package
- ✅ Creative filament recommendations
- ✅ Safety protocols
- ✅ Week-by-week timeline

**Next immediate action**:
1. Open `OpenDuck_Mini_V3_ENHANCED_BOM.xlsx`
2. Review SUMMARY sheet
3. Join Discord
4. Verify servo availability
5. **Place Amazon.it order TODAY** (start with safety gear + fast items)

---

**Good luck building your enhanced OpenDuck Mini V3!** 🤖👁️🦾

**Share your progress on Discord!**
**Tag your build photos**: `#OpenDuckV3Enhanced`

---

*Document created: 2026-01-11*
*By: Claude Code (Sonnet 4.5)*
*Based on: Official OpenDuck Mini V2 BOM + Custom Enhancements*
*Excel file: OpenDuck_Mini_V3_ENHANCED_BOM.xlsx*
