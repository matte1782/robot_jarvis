# JARVIS: First 30 Minutes Checklist

Your step-by-step guide to getting JARVIS running from zero.

---

## Prerequisites (Before Starting)

- [ ] Windows 10/11 PC with 8GB+ RAM
- [ ] Internet connection for downloads
- [ ] Python 3.11+ installed (`winget install Python.Python.3.11`)
- [ ] Claude Desktop installed with active subscription

---

## Phase 1: Setup (10 minutes)

### Step 1: Clone or Download
```powershell
cd ~\Projects
git clone https://github.com/yourusername/robot_jarvis.git
cd robot_jarvis
```

### Step 2: Run Setup Script
```powershell
.\setup.ps1
```

This will:
- [x] Check Python version
- [x] Create virtual environment
- [x] Install all dependencies
- [x] Download Ollama + qwen2.5:7b model
- [x] Create .env file

### Step 3: Configure .env
Open `.env` and update:
```ini
JARVIS_WORKSPACE=C:\Users\YOUR_NAME\.jarvis\workspace
```

---

## Phase 2: Claude Desktop Integration (5 minutes)

### Step 4: Copy MCP Config
```powershell
Copy-Item config\claude_desktop_config.example.json "$env:APPDATA\Claude\claude_desktop_config.json"
```

### Step 5: Edit Paths
Open `%APPDATA%\Claude\claude_desktop_config.json` and replace:
- `PROJECT_PATH` with actual repo path
- `YOUR_USERNAME` with Windows username

### Step 6: Restart Claude Desktop
Close and reopen Claude Desktop to load MCP servers.

---

## Phase 3: First Run (5 minutes)

### Step 7: Start JARVIS
```powershell
.\start_jarvis.ps1 -Voice
```

### Step 8: Test Voice
- Hold **F9** and say "Hello JARVIS"
- Release F9
- Wait for response (audio + text)

### Step 9: Test Claude Integration
In Claude Desktop, type:
> "List files in my workspace"

JARVIS should respond with your workspace contents.

---

## Phase 4: Verification (5 minutes)

### Step 10: Run Tests
```powershell
.\.venv\Scripts\Activate.ps1
pytest tests/ -v
```

Expected: All tests pass

### Step 11: Check Dashboard (Optional)
```powershell
.\start_jarvis.ps1 -Dashboard
```
Open http://localhost:5000

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Python not found" | Install Python 3.11+ |
| "Ollama not running" | Run `ollama serve` in separate terminal |
| "MCP servers not loading" | Check paths in claude_desktop_config.json |
| "No audio output" | Check speaker volume, verify edge-tts install |
| "F9 not responding" | Try running as admin (not normally needed) |

---

## Success Criteria

After 30 minutes you should have:

- [x] JARVIS responding to voice commands
- [x] Claude Desktop seeing MCP file/shell servers
- [x] Tests passing
- [x] Dashboard showing system status

---

## Next Steps

1. **Customize** `.env` for your preferences
2. **Try** different Ollama models (14B if you have GPU)
3. **Explore** docs/HOLOGRAPHIC_UI.md for display options
4. **Read** docs/SECURITY_MODEL.md for security details

---

*Built with Claude Code - 2026-01-10*
