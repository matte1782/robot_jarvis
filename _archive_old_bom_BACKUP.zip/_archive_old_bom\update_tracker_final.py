from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

wb = load_workbook('OPENDUCK_V3_MASTER_TRACKER.xlsx')
ws = wb.active

# Find optional section and add LED ring
optional_section_row = None
for row in range(1, ws.max_row + 1):
    cell_value = ws.cell(row, 1).value
    if cell_value and 'FASE 5' in str(cell_value):
        optional_section_row = row
        print(f'Found FASE 5 at row {row}')
        break

if optional_section_row:
    # Find first data row after headers (row + 2)
    led_row = optional_section_row + 2

    # Insert LED ring BEFORE existing optional items
    ws.insert_rows(led_row)

    # Add LED ring data
    ws.cell(led_row, 1).value = '⭐'
    ws.cell(led_row, 2).value = 'WS2812B 16-LED NeoPixel Ring (RACCOMANDATO)'
    ws.cell(led_row, 3).value = 8.99
    ws.cell(led_row, 4).value = 'Amazon.it'
    ws.cell(led_row, 5).value = 'OPZIONALE'
    ws.cell(led_row, 6).value = 'Expression system - 30min install vs 80hr holographic'
    ws.cell(led_row, 7).value = 'RECOMMENDED'
    ws.cell(led_row, 8).value = '13-16 gen'

    # Color it light green (recommended alternative)
    for col in range(1, 9):
        ws.cell(led_row, col).fill = PatternFill(start_color='D9EAD3', end_color='D9EAD3', fill_type='solid')
        ws.cell(led_row, col).font = Font(bold=False)

    print(f'Added LED ring at row {led_row}')

# Update gripper quantity and price (should already be done)
for row in range(1, ws.max_row + 1):
    cell_value = ws.cell(row, 2).value
    if cell_value and '2DOF' in str(cell_value) and 'Gripper' in str(cell_value):
        ws.cell(row, 2).value = '2DOF Aluminum Robot Gripper Kit (2 pezzi)'
        ws.cell(row, 3).value = 54.00
        ws.cell(row, 6).value = '15cm reach, 50g payload - SYMMETRIC arms REQUIRED'
        print(f'Updated gripper at row {row}')
        break

# Recalculate optional total
optional_total_row = None
for row in range(optional_section_row, ws.max_row + 1):
    cell_value = ws.cell(row, 3).value
    if cell_value and 'TOTALE OPZIONALI' in str(ws.cell(row, 2).value or ''):
        optional_total_row = row
        break

if optional_total_row:
    # Find data rows for summation
    start_row = optional_section_row + 3
    end_row = optional_total_row - 1
    ws.cell(optional_total_row, 4).value = f'=SUM(D{start_row}:D{end_row})'
    print(f'Updated optional total formula at row {optional_total_row}')

wb.save('OPENDUCK_V3_MASTER_TRACKER.xlsx')
print('')
print('TRACKER AGGIORNATO CON SUCCESSO!')
print('')
print('MODIFICHE:')
print('1. Gripper: 1 pezzo -> 2 pezzi (EUR 27 -> EUR 54)')
print('2. LED Ring aggiunto: EUR 8.99 (RECOMMENDED)')
print('3. Holographic eye: REJECTED (non aggiunto)')
print('4. Totali ricalcolati')
