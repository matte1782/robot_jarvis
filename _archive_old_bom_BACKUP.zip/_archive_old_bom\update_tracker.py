from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

wb = load_workbook('AMAZON_IT_SHOPPING_TRACKER.xlsx')

# Add CHECKLIST sheet as first sheet
if 'CHECKLIST' in wb.sheetnames:
    del wb['CHECKLIST']

ws_check = wb.create_sheet('CHECKLIST', 0)

# Header
ws_check['A1'] = 'CHECKLIST COMPLETA - ORDINE COMPONENTI OPENDUCK V3'
ws_check['A1'].font = Font(size=16, bold=True, color='FFFFFF')
ws_check['A1'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
ws_check['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws_check.merge_cells('A1:E1')
ws_check.row_dimensions[1].height = 30

ws_check.column_dimensions['A'].width = 8
ws_check.column_dimensions['B'].width = 55
ws_check.column_dimensions['C'].width = 18
ws_check.column_dimensions['D'].width = 12
ws_check.column_dimensions['E'].width = 45

headers = ['OK', 'Azione', 'Fornitore', 'Importo', 'Note']
for col, header in enumerate(headers, 1):
    cell = ws_check.cell(2, col, header)
    cell.font = Font(bold=True, color='FFFFFF')
    cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    cell.alignment = Alignment(horizontal='center')

row = 3

# FASE 1 - AMAZON
ws_check[f'A{row}'] = 'FASE 1 - ORDINE AMAZON.IT (ORDINA SUBITO)'
ws_check[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws_check[f'A{row}'].fill = PatternFill(start_color='70AD47', end_color='70AD47', fill_type='solid')
ws_check.merge_cells(f'A{row}:E{row}')
row += 1

amazon_start = row
items_amazon = [
    ('Verifica carrello: 5 filamenti + heat set inserts', 'Amazon.it', 181.53, 'GIA NEL CARRELLO - verifica presenza'),
    ('Aggiungi Raspberry Pi Zero 2W (512MB RAM)', 'Amazon.it', 23.80, 'Risparmio vs Melopero!'),
    ('Aggiungi SanDisk microSD 32GB', 'Amazon.it', 8.00, 'OS storage'),
    ('Aggiungi TTLinker Level Shifter', 'Amazon.it', 10.00, 'Se servos 5V TTL'),
    ('Aggiungi UBEC 7.4V 10A (SERVOS)', 'Amazon.it', 25.00, 'CRITICO - 7.4V richiesto!'),
    ('Aggiungi UBEC 5V 3A (Electronics)', 'Amazon.it', 8.00, 'Rail separato RPi'),
    ('Aggiungi 2S BMS 20A', 'Amazon.it', 12.00, 'CRITICO - 20A minimo'),
    ('Aggiungi XT30 Connectors (5 pairs)', 'Amazon.it', 8.00, 'Power distribution'),
    ('Aggiungi HC-SR04 Ultrasonic Sensor', 'Amazon.it', 3.00, 'Obstacle detection'),
    ('Aggiungi Jumper Wire Kit 120pcs', 'Amazon.it', 8.00, 'Sensor wiring'),
    ('Aggiungi Servo Extension 30cm (10pcs)', 'Amazon.it', 12.00, 'Wiring servos'),
    ('Aggiungi M2/M2.5/M3 Screw Kit 1080pcs', 'Amazon.it', 15.00, 'Assembly hardware'),
    ('Aggiungi M3 Ball Bearings 10pcs', 'Amazon.it', 8.00, 'Low friction joints'),
    ('Aggiungi Pi Zero Camera Cable 15cm', 'Amazon.it', 5.00, 'Head mounting'),
    ('Aggiungi MG90S Servo 13g (4pcs) - BRACCIA', 'Amazon.it', 16.00, 'Per arm joints'),
    ('Aggiungi Servo Extension 15cm (8pcs) - BRACCIA', 'Amazon.it', 8.00, 'Wiring arms'),
    ('Aggiungi Servo Horn 25T (4pcs) - BRACCIA', 'Amazon.it', 6.00, 'Heavy-duty horn'),
    ('Aggiungi Soldering Iron Kit 60W', 'Amazon.it', 25.00, 'Power connections'),
    ('Aggiungi Kapton Tape 20mm x 33m', 'Amazon.it', 8.00, 'Heat-resistant'),
    ('PROCEDI AL CHECKOUT AMAZON.IT', 'Amazon.it', 0.00, 'Ordine unico - risparmio spedizione!'),
]

for item in items_amazon:
    ws_check.cell(row, 1, '')
    ws_check.cell(row, 2, item[0])
    ws_check.cell(row, 3, item[1])
    ws_check.cell(row, 4, item[2])
    ws_check.cell(row, 4).number_format = '#,##0.00'
    ws_check.cell(row, 5, item[3])

    if 'GIA NEL CARRELLO' in item[3]:
        for col in range(1, 6):
            ws_check.cell(row, col).fill = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')
    elif 'CRITICO' in item[3]:
        for col in range(1, 6):
            ws_check.cell(row, col).fill = PatternFill(start_color='FFE699', end_color='FFE699', fill_type='solid')
    elif 'BRACCIA' in item[0]:
        for col in range(1, 6):
            ws_check.cell(row, col).fill = PatternFill(start_color='DEEBF7', end_color='DEEBF7', fill_type='solid')
    elif 'CHECKOUT' in item[0]:
        for col in range(1, 6):
            ws_check.cell(row, col).fill = PatternFill(start_color='C6E0B4', end_color='C6E0B4', fill_type='solid')
            ws_check.cell(row, col).font = Font(bold=True)

    row += 1

ws_check[f'C{row}'] = 'TOTALE AMAZON:'
ws_check[f'C{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'] = f'=SUM(D{amazon_start}:D{row-1})'
ws_check[f'D{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'].number_format = '#,##0.00'
ws_check[f'D{row}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
amazon_total_row = row
row += 2

# FASE 2 - ALTRI FORNITORI
ws_check[f'A{row}'] = 'FASE 2 - ALTRI FORNITORI (PARALLELO AD AMAZON)'
ws_check[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws_check[f'A{row}'].fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
ws_check.merge_cells(f'A{row}:E{row}')
row += 1

others_start = row
items_others = [
    ('Ordina Molicel INR18650-P30B (2x)', 'TheBatteryShop.eu', 14.00, 'VERIFIED supplier - controlla QR code!'),
    ('Ordina Raspberry Pi AI Camera IMX500', 'Pimoroni.uk', 70.00, 'Computer vision eyes - on-sensor AI'),
    ('Ordina Adafruit BNO085 9-DOF IMU', 'Pimoroni.uk', 38.00, 'REPLACES obsolete BNO055'),
]

for item in items_others:
    ws_check.cell(row, 1, '')
    ws_check.cell(row, 2, item[0])
    ws_check.cell(row, 3, item[1])
    ws_check.cell(row, 4, item[2])
    ws_check.cell(row, 4).number_format = '#,##0.00'
    ws_check.cell(row, 5, item[3])
    row += 1

ws_check[f'C{row}'] = 'TOTALE ALTRI:'
ws_check[f'C{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'] = f'=SUM(D{others_start}:D{row-1})'
ws_check[f'D{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'].number_format = '#,##0.00'
ws_check[f'D{row}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
others_total_row = row
row += 2

# FASE 3 - ECKSTEIN (RED)
ws_check[f'A{row}'] = 'FASE 3 - ATTENDI CONFERMA ECKSTEIN (NON ORDINARE ANCORA!)'
ws_check[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws_check[f'A{row}'].fill = PatternFill(start_color='C00000', end_color='C00000', fill_type='solid')
ws_check.merge_cells(f'A{row}:E{row}')
row += 1

eckstein_start = row
items_eckstein = [
    ('Invia email a info@eckstein-shop.de', 'Eckstein-shop.de', 0.00, 'Richiesta quotazione STS3215 (16x servos)'),
    ('ASPETTA risposta con prezzo e disponibilita', 'Eckstein-shop.de', 0.00, 'NON ordinare su AliExpress - rischio contraffazioni!'),
    ('Ordina Feetech STS3215 Servo 7.4V (16x)', 'Eckstein-shop.de', 400.00, 'STIMA 320-480 EUR - conferma prima ordine'),
]

for item in items_eckstein:
    ws_check.cell(row, 1, '')
    ws_check.cell(row, 2, item[0])
    ws_check.cell(row, 3, item[1])
    ws_check.cell(row, 4, item[2])
    ws_check.cell(row, 4).number_format = '#,##0.00'
    ws_check.cell(row, 5, item[3])

    for col in range(1, 6):
        ws_check.cell(row, col).fill = PatternFill(start_color='F4CCCC', end_color='F4CCCC', fill_type='solid')
        ws_check.cell(row, col).font = Font(color='C00000')

    row += 1

ws_check[f'C{row}'] = 'STIMA ECKSTEIN:'
ws_check[f'C{row}'].font = Font(bold=True, size=11, color='C00000')
ws_check[f'D{row}'] = 400.00
ws_check[f'D{row}'].font = Font(bold=True, size=11, color='C00000')
ws_check[f'D{row}'].number_format = '#,##0.00'
ws_check[f'D{row}'].fill = PatternFill(start_color='F4CCCC', end_color='F4CCCC', fill_type='solid')
eckstein_total_row = row
row += 2

# OPZIONALI
ws_check[f'A{row}'] = 'OPZIONALI - ALIEXPRESS (NON URGENTE)'
ws_check[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws_check[f'A{row}'].fill = PatternFill(start_color='7030A0', end_color='7030A0', fill_type='solid')
ws_check.merge_cells(f'A{row}:E{row}')
row += 1

optional_start = row
items_optional = [
    ('2DOF Aluminum Robot Gripper Kit', 'AliExpress', 25.00, 'Ordinabile dopo - spedizione lenta 15-30 giorni'),
    ('Acrylic Dome Lenses 25mm (2pcs eyes)', 'AliExpress', 8.00, 'Clear hemispheres per eye effect'),
    ('Feetech USB-TTL Adapter firmware', 'AliExpress', 15.00, 'Solo se servos hanno firmware sbagliato'),
]

for item in items_optional:
    ws_check.cell(row, 1, '')
    ws_check.cell(row, 2, item[0])
    ws_check.cell(row, 3, item[1])
    ws_check.cell(row, 4, item[2])
    ws_check.cell(row, 4).number_format = '#,##0.00'
    ws_check.cell(row, 5, item[3])

    for col in range(1, 6):
        ws_check.cell(row, col).fill = PatternFill(start_color='E4DFEC', end_color='E4DFEC', fill_type='solid')

    row += 1

ws_check[f'C{row}'] = 'TOTALE OPZIONALI:'
ws_check[f'C{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'] = f'=SUM(D{optional_start}:D{row-1})'
ws_check[f'D{row}'].font = Font(bold=True, size=11)
ws_check[f'D{row}'].number_format = '#,##0.00'
ws_check[f'D{row}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
optional_total_row = row
row += 2

# TOTALE PROGETTO
ws_check[f'A{row}'] = 'TOTALE PROGETTO COMPLETO'
ws_check[f'A{row}'].font = Font(bold=True, size=14, color='FFFFFF')
ws_check[f'A{row}'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
ws_check.merge_cells(f'A{row}:C{row}')
ws_check[f'D{row}'] = f'=D{amazon_total_row}+D{others_total_row}+D{eckstein_total_row}+D{optional_total_row}'
ws_check[f'D{row}'].font = Font(bold=True, size=14, color='FFFFFF')
ws_check[f'D{row}'].number_format = '#,##0.00'
ws_check[f'D{row}'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
ws_check[f'E{row}'] = '(esclude stampante QIDI gia acquistata 599 EUR)'
ws_check[f'E{row}'].font = Font(italic=True, size=10, color='FFFFFF')
ws_check[f'E{row}'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')

# Update ALTRI_FORNITORI to highlight Eckstein in red
ws2 = wb['ALTRI_FORNITORI']
for row_num in range(3, ws2.max_row + 1):
    if ws2.cell(row_num, 1).value and 'ECKSTEIN' in str(ws2.cell(row_num, 1).value).upper():
        for col in range(1, 7):
            ws2.cell(row_num, col).fill = PatternFill(start_color='F4CCCC', end_color='F4CCCC', fill_type='solid')
            ws2.cell(row_num, col).font = Font(bold=True, color='C00000')

wb.save('AMAZON_IT_SHOPPING_TRACKER_AGGIORNATO.xlsx')
print('Excel aggiornato con successo!')
print('')
print('MODIFICHE EFFETTUATE:')
print('1. Creato foglio CHECKLIST (prima posizione)')
print('2. Aggiunto Raspberry Pi Zero 2W a 23.80 EUR')
print('3. Aggiunta sezione BRACCIA FUNZIONALI')
print('4. Componenti Eckstein evidenziati in ROSSO')
print('5. Opzionali AliExpress separati')
print('')
print('TOTALE PROGETTO: ~911 EUR (Amazon + Altri + Eckstein + Opzionali)')
