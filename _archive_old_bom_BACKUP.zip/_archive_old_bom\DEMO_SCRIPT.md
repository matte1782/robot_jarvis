# JARVIS Demo Script

A guided demonstration of JARVIS capabilities for presentations and testing.

---

## Demo Setup (5 min before)

```powershell
# Terminal 1: Start voice pipeline
.\start_jarvis.ps1 -Voice

# Terminal 2: Start dashboard
.\start_jarvis.ps1 -Dashboard

# Open browser to http://localhost:5000
```

---

## Demo Flow

### Act 1: Voice Interaction (2 min)

**Narrator**: "JARVIS uses push-to-talk for privacy. No always-listening."

1. **Hold F9**, say: "Hello JARVIS, what can you do?"
   - *Expected*: Introduction response via TTS

2. **Hold F9**, say: "What's the weather like today?"
   - *Expected*: Response (may defer to Claude for real-time data)

3. **Hold F9**, say: "Set a reminder to review the project"
   - *Expected*: Confirmation + task noted

---

### Act 2: Claude Desktop Integration (3 min)

**Narrator**: "JARVIS extends Claude with local file and shell access via MCP."

1. **In Claude Desktop**, type: "List the files in my workspace"
   - *Expected*: MCP file server returns workspace listing

2. Type: "Create a file called test_note.txt with 'Hello from JARVIS'"
   - *Expected*: File created in workspace

3. Type: "What's my Python version?"
   - *Expected*: MCP shell server runs `python --version`

---

### Act 3: Offline Capabilities (2 min)

**Narrator**: "JARVIS works offline using local Ollama models."

1. **Disable internet** (airplane mode or disconnect)

2. **Hold F9**, say: "What is the capital of France?"
   - *Expected*: Ollama responds (qwen2.5:7b)

3. **Hold F9**, say: "Write a haiku about programming"
   - *Expected*: Local LLM generates haiku

4. **Reconnect internet**

---

### Act 4: Dashboard & Monitoring (2 min)

**Narrator**: "The web dashboard shows real-time system status."

1. **Show browser** at http://localhost:5000
   - Point out: Status, Uptime, Ollama status, Mode

2. **Click** "Toggle Offline Mode"
   - *Expected*: Mode switches between Online/Offline

3. **Show** conversation memory section
   - Point out: History preserved across sessions

4. **Click** "Clear Memory"
   - *Expected*: Confirmation dialog, then cleared

---

### Act 5: Security Features (1 min)

**Narrator**: "Security is built-in, not bolted on."

Explain:
- Push-to-talk prevents eavesdropping
- MCP shell uses allowlist (can't run arbitrary commands)
- File access sandboxed to workspace
- API keys hashed with SHA-256
- All CV processing local-only

---

## Demo Highlights to Emphasize

1. **Privacy First**: Push-to-talk, no persistent recording
2. **Offline Capable**: Works without internet (Ollama)
3. **Claude Integration**: MCP extends Claude safely
4. **Open Source**: Full code available, no black boxes
5. **EU Focused**: All hardware sourced from EU vendors

---

## Backup Responses (if things go wrong)

| Issue | Recovery |
|-------|----------|
| Voice not responding | "Let me check Ollama is running... `ollama serve`" |
| Claude MCP fails | "MCP servers may need restart. Let me refresh Claude Desktop." |
| Dashboard offline | "The dashboard runs on port 5000. Let me start it." |
| Audio issues | "My speakers might be muted. Let me check system audio." |

---

## Closing

**Narrator**: "JARVIS brings AI assistant capabilities to your desktop with privacy and control. The code is open source, the hardware is EU-sourced, and Claude integration is seamless via MCP."

**Call to Action**:
- GitHub: github.com/yourusername/robot_jarvis
- Documentation: See docs/ folder
- Hardware: See bom/ for shopping lists

---

*Demo script v1.0 - 2026-01-10*
