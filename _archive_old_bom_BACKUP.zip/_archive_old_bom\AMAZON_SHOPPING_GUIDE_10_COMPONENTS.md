# GUIDA SHOPPING RAPIDA - 10 COMPONENTI MANCANTI
## OpenDuck Mini V3 Enhanced - Amazon.it

**TEMPO STIMATO:** 5-7 minuti
**MODALITÀ:** Copia/incolla i termini di ricerca, clicca primo risultato con 4+ stelle Prime

---

## ✅ COMPONENTE 1/10 - Jumper Wire Kit 120pcs

**Cerca su Amazon.it:**
```
ELEGOO 120pcs jumper wire dupont
```

**COSA VERIFICARE:**
- ✅ Marca: ELEGOO (preferito) o AZDelivery
- ✅ Quantità: 120 pezzi (40× M-M, 40× M-F, 40× F-F)
- ✅ AWG: 24AWG o 26AWG
- ✅ Recensioni: 4+ stelle
- ✅ Prezzo: €8-10

**PRODOTTO RACCOMANDATO:**
- ELEGOO 120pcs Kit - €9.99 - 4.7⭐ (2007 recensioni)

---

## ✅ COMPONENTE 2/10 - Servo Extension Cable 30cm

**Cerca su Amazon.it:**
```
servo extension cable 30cm 10pcs JR
```

**COSA VERIFICARE:**
- ✅ Lunghezza: 30cm (non 15cm!)
- ✅ Quantità: 10 pezzi minimum
- ✅ Tipo: JR/Futaba plug (standard)
- ✅ AWG: 22AWG o migliore
- ✅ Prezzo: €10-14

**ALTERNATIVE se non trovi 30cm:**
- Cerca: `servo extension cable 20cm 10pcs` (OK anche 20cm)

---

## ✅ COMPONENTE 3/10 - M2/M2.5/M3 Screw Kit

**Cerca su Amazon.it:**
```
M2 M2.5 M3 screw kit 1080pcs assortment
```

**COSA VERIFICARE:**
- ✅ Include: M2, M2.5, M3 (tutti e tre!)
- ✅ Quantità: 1000+ pezzi
- ✅ Tipo: Socket head cap screws
- ✅ Materiale: Acciaio inox (stainless steel)
- ✅ Include nuts (dadi)
- ✅ Prezzo: €12-18

**ALTERNATIVE:**
- Se non trovi assortment misto, va bene anche solo M3 screw kit 500pcs

---

## ✅ COMPONENTE 4/10 - M3 Ball Bearings

**Cerca su Amazon.it:**
```
MR63ZZ ball bearing 10pcs 3x6x2.5mm
```

**COSA VERIFICARE:**
- ✅ Modello: MR63ZZ (standard per M3)
- ✅ Dimensioni: 3mm ID × 6mm OD × 2.5mm thickness
- ✅ Quantità: 10 pezzi minimum
- ✅ ZZ = double shielded (sigillati)
- ✅ Prezzo: €6-10

**ALTERNATIVE:**
- Cerca: `ball bearing 3x6x2.5` se non trovi MR63ZZ

---

## ✅ COMPONENTE 5/10 - Pi Zero Camera Cable

**Cerca su Amazon.it:**
```
raspberry pi zero camera cable 15cm
```

**COSA VERIFICARE:**
- ✅ ATTENZIONE: Per Pi ZERO (non full-size Pi!)
- ✅ Lunghezza: 15cm (perfetto per head mounting)
- ✅ Tipo: Ribbon cable flessibile
- ✅ Compatibilità: Pi Zero / Pi Zero 2W
- ✅ Prezzo: €4-7

**VERIFICA IMPORTANTE:**
- Il cavo Pi Zero è PIÙ STRETTO del cavo Pi normale!
- Cerca "Pi Zero camera cable" NOT "Raspberry Pi camera cable"

---

## ✅ COMPONENTE 6/10 - MG90S Metal Gear Servos

**Cerca su Amazon.it:**
```
MG90S metal gear servo 4pcs
```

**COSA VERIFICARE:**
- ✅ Modello: MG90S (non MG90 plastic!)
- ✅ Gears: METAL (non plastic - critico!)
- ✅ Quantità: 4 pezzi (per 2DOF arms)
- ✅ Peso: ~13g
- ✅ Coppia: ~2.2kg·cm @ 6V
- ✅ Prezzo: €14-18 per 4pcs

**ALTERNATIVE:**
- Se non trovi 4pcs, va bene 2× confezioni da 2pcs

---

## ✅ COMPONENTE 7/10 - Servo Extension Cable 15cm

**Cerca su Amazon.it:**
```
servo extension cable 15cm 8pcs
```

**COSA VERIFICARE:**
- ✅ Lunghezza: 15cm (più corti per arms)
- ✅ Quantità: 8 pezzi minimum
- ✅ Tipo: JR/Futaba plug
- ✅ Prezzo: €7-10

**NOTE:**
- Possono essere same type delle extension 30cm, solo lunghezza diversa

---

## ✅ COMPONENTE 8/10 - Aluminum Servo Horns

**Cerca su Amazon.it:**
```
aluminum servo horn 25T 4pcs
```

**COSA VERIFICARE:**
- ✅ Materiale: Alluminio (non plastic!)
- ✅ Teeth: 25T (25 denti - standard)
- ✅ Quantità: 4 pezzi
- ✅ Compatibilità: MG90S / 9g servos
- ✅ Prezzo: €5-8

**ALTERNATIVE:**
- Se non trovi 25T, va bene 24T o 23T

---

## ✅ COMPONENTE 9/10 - Soldering Iron Kit

**Cerca su Amazon.it:**
```
soldering iron kit 60W stand temperature control
```

**COSA VERIFICARE:**
- ✅ Potenza: 60W minimum (meglio 80W)
- ✅ Include: Stand (supporto)
- ✅ Temperature control: Regolabile (critico!)
- ✅ Include: Tips (punte varie)
- ✅ Prezzo: €20-30

**FEATURES BONUS (non obbligatorio):**
- Digital display temperature
- Sponge + brass cleaner
- Carrying case

---

## ✅ COMPONENTE 10/10 - Kapton Tape

**Cerca su Amazon.it:**
```
kapton tape 20mm 33m high temperature
```

**COSA VERIFICARE:**
- ✅ Larghezza: 20mm (va bene anche 10mm o 15mm)
- ✅ Lunghezza: 30m+ (33m ideale)
- ✅ Tipo: Polyimide (Kapton è brand name)
- ✅ Temperature: 200°C+ rated
- ✅ Prezzo: €6-10

**ALTERNATIVE:**
- "polyimide tape 20mm" = stesso prodotto, generic name

---

## 📊 RIEPILOGO PREZZI:

| # | Componente | Prezzo Target | Prezzo Max |
|---|------------|---------------|------------|
| 1 | Jumper Wires | €9-10 | €12 |
| 2 | Servo Extension 30cm | €10-12 | €15 |
| 3 | Screw Kit | €12-15 | €18 |
| 4 | Ball Bearings | €6-8 | €10 |
| 5 | Pi Zero Cable | €4-5 | €7 |
| 6 | MG90S Servos | €14-16 | €20 |
| 7 | Servo Extension 15cm | €7-8 | €10 |
| 8 | Servo Horns | €5-6 | €8 |
| 9 | Soldering Iron | €20-25 | €30 |
| 10 | Kapton Tape | €6-8 | €10 |
| **TOTALE** | **€93-108** | **€140** |

---

## 🎯 STRATEGIA SHOPPING VELOCE:

### METODO A - 5 MINUTI (Raccomandato):
1. Apri Amazon.it in una tab
2. Per ogni componente:
   - Copia/incolla il termine di ricerca
   - Clicca sul primo risultato con:
     - 4+ stelle ⭐
     - Prime delivery 📦
     - Prezzo entro budget
   - Clicca "Aggiungi al carrello"
3. FATTO!

### METODO B - 10 MINUTI (Più accurato):
1. Leggi "COSA VERIFICARE" per ogni componente
2. Confronta 2-3 opzioni
3. Scegli quello con più recensioni + Prime
4. Aggiungi al carrello

---

## ⚠️ ERRORI COMUNI DA EVITARE:

1. **Pi Camera Cable:** NON comprare cavo per Pi full-size! (troppo largo)
2. **MG90S Servos:** Verifica che siano METAL gear (non plastic)
3. **Servo Horns:** Verifica compatibilità con MG90S (25T standard)
4. **Screw Kit:** Meglio assortment misto M2/M2.5/M3 che solo M3
5. **Soldering Iron:** DEVE avere temperature control (non fisso)

---

## ✅ CHECKLIST FINALE:

Dopo aver aggiunto tutti e 10 componenti, verifica carrello:

- [ ] Jumper Wires 120pcs
- [ ] Servo Extension 30cm (10pcs)
- [ ] M2/M2.5/M3 Screw Kit
- [ ] M3 Ball Bearings (10pcs)
- [ ] Pi Zero Camera Cable 15cm
- [ ] MG90S Metal Gear Servos (4pcs)
- [ ] Servo Extension 15cm (8pcs)
- [ ] Aluminum Servo Horns 25T (4pcs)
- [ ] Soldering Iron Kit 60W
- [ ] Kapton Tape 20mm

**TOTALE CARRELLO AMAZON.IT FINALE:** ~€290-300

Poi ordini separatamente:
- 2× Molicel P30B batterie (vape shop locale - €14-18)
- Pimoroni UK: AI Camera + BNO085 IMU (~€108)
- Eckstein: 16× STS3215 servos (~€400 - attendi quotazione!)

---

## 🚀 DOPO L'ORDINE:

1. ✅ Conferma ordine Amazon.it
2. 🏪 Vai al vape shop per batterie (OGGI!)
3. 🌍 Ordina Pimoroni UK
4. ⏳ Aspetta risposta Eckstein per servos
5. 🎉 Sei PRONTO per l'assemblaggio!

---

**BUONO SHOPPING! 🛒**
