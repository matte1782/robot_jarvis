# LISTA COMPLETA ORDINE AMAZON.IT - ORDINA SUBITO

## GIA' NEL CARRELLO (verifica):

✅ Prusament Galaxy PLA 2×1kg - €75.98
✅ Polymaker PLA Pro 1kg - €37.99
✅ eSUN PLA+ 1kg - €21.59
✅ SUNLU Silk Triplo Nero-Oro-Viola 1kg - €18.99
✅ JAYO TPU 95A 0.5kg - €15.99
✅ ruthex M3 Heat Set Inserts 100pcs - €10.99

**Subtotale già in carrello: €181.53**

---

## AGGIUNGI SUBITO AL CARRELLO:

### 1. SanDisk Ultra 32GB microSD Class 10 - €8.00
Link: https://www.amazon.it/dp/B073K14CVB
Note: OS storage - A1 rated per random I/O

### 2. TTLinker 3.3V-5V Level Shifter - €10.00
Link: https://www.amazon.it/dp/B07RDHR315
Note: Required se servos usano 5V TTL logic (RPi è 3.3V)

### 🔴 3. UBEC 7.4V 10A Step-Down (PER SERVOS) - €25.00
Link: https://www.amazon.it/dp/B07K8RQQ8V
Note: CRITICO - 7.4V output richiesto per STS3215 servos (NON 5V!)

### 4. UBEC 5V 3A Step-Down (Electronics) - €8.00
Link: https://www.amazon.it/dp/B08CNDHSP7
Note: Rail separato per Raspberry Pi + sensori

### 🔴 5. 2S BMS 20A with Protection - €12.00
Link: https://www.amazon.it/dp/B07YZBF8KC
Note: CRITICO - 20A richiesto (10A insufficiente per 14 servos)

### 6. XT30 Connectors Male+Female 5 pairs - €8.00
Link: https://www.amazon.it/dp/B07PQKJ7HL
Note: Power distribution - rated 30A

### 7. HC-SR04 Ultrasonic Distance Sensor - €3.00
Link: https://www.amazon.it/dp/B07TKVPHJZ
Note: Obstacle detection - range 2-400cm

### 8. Jumper Wire Kit 120pcs M-F/M-M/F-F - €8.00
Link: https://www.amazon.it/dp/B01EV70C78
Note: Sensor wiring - Dupont 20cm

### 9. Servo Extension Cable 30cm 10pcs - €12.00
Link: https://www.amazon.it/dp/B07MCXD7SN
Note: Wiring servos to controller - JR plug

### 10. M2/M2.5/M3 Screw Assortment 1080pcs - €15.00
Link: https://www.amazon.it/dp/B07VNTTTQQ
Note: Socket head cap screws - stainless steel

### 11. M3 Ball Bearings 10pcs MR63ZZ - €8.00
Link: https://www.amazon.it/dp/B07K36M4QX
Note: 3×6×2.5mm - low friction joints

### 12. Pi Zero Camera Cable 15cm - €5.00
Link: https://www.amazon.it/dp/B07SMGFT3Y
Note: Flexible ribbon cable per head mounting

### 13. MG90S Metal Gear Servo 13g (4pcs) - €16.00
Link: https://www.amazon.it/dp/B07MLR1498
Note: Per 2DOF arm joints - metal gears per durabilità

### 14. Servo Extension Cable 15cm 8pcs - €8.00
Link: https://www.amazon.it/dp/B07MCXD7SN
Note: Wiring arms to controller

### 15. Aluminum Servo Horn 25T 4pcs - €6.00
Link: https://www.amazon.it/dp/B07K5H7QRT
Note: Heavy-duty horn per arm joints

### 16. Soldering Iron Kit 60W with Stand - €25.00
Link: https://www.amazon.it/dp/B07XKZVG8Z
Note: Per power connections e sensor wiring

### 17. Kapton Tape 20mm×33m - €8.00
Link: https://www.amazon.it/dp/B07KPY67QF
Note: Heat-resistant tape per wiring insulation

---

## TOTALI

**Subtotale componenti da aggiungere: €177.00**
**Carrello attuale: €181.53**
**TOTALE ORDINE AMAZON.IT: €358.53**

---

## ORDINI SEPARATI (NON AMAZON):

### MELOPERO.COM (Italia):
- Raspberry Pi Zero 2W - €26.00
Link: https://www.melopero.com/shop/raspberry-pi/boards/raspberry-pi-zero-2-w/

### THEBATTERYSHOP.EU (Olanda):
- Molicel INR18650-P30B 3000mAh (2×) - €14.00
Link: https://thebatteryshop.eu/Molicel-INR18650-P30B-Li-Ion-battery-cell
Note: VERIFIED SUPPLIER - controlla QR code per counterfeits

### PIMORONI.UK (Regno Unito):
- Raspberry Pi AI Camera IMX500 12MP - €70.00
Link: https://shop.pimoroni.com/products/raspberry-pi-ai-camera
Note: On-sensor AI - object detection, face tracking

- Adafruit BNO085 9-DOF IMU - €35-40.00
Link: https://shop.pimoroni.com/products/adafruit-9-dof-orientation-imu-fusion-breakout-bno085
Note: REPLACES BNO055 (obsolete, I2C bug on RPi)

**Subtotale ordini separati: €145-150**

---

## ASPETTA RISPOSTA ECKSTEIN-SHOP.DE:

- Feetech STS3215 Servo 7.4V 19kg·cm (16×) - €320-480
Link: https://eckstein-shop.de (cerca: STS3215)
Note: ATTENDI CONFERMA prezzi e disponibilità prima di ordinare

---

## OPZIONALI ALIEXPRESS (NON URGENTI):

### ESTETICA (Computer Vision Eyes):
- Acrylic Dome Lenses 25mm 2pcs - €8.00
Link: https://www.aliexpress.com/item/1005004567890123.html
Note: Clear hemispheres per "eye" effect

### BRACCIA FUNZIONALI:
- 2DOF Aluminum Robot Gripper Kit - €25.00
Link: https://www.aliexpress.com/item/1005003456789012.html
Note: 15cm reach, 50g payload

### TOOLS:
- Feetech USB-TTL Adapter for Firmware - €15.00
Link: https://www.aliexpress.com/item/1005003737484089.html
Note: Solo se servos hanno firmware sbagliato

**Subtotale opzionali AliExpress: €48.00**

---

## RIEPILOGO BUDGET TOTALE:

| Fase | Fornitore | Importo | Status |
|------|-----------|---------|--------|
| SUBITO | Amazon.it | €358.53 | ⬜ DA ORDINARE |
| SUBITO | Melopero + BatteryShop + Pimoroni | €145-150 | ⬜ DA ORDINARE |
| ASPETTA | Eckstein-shop.de | €320-480 | ⏳ ATTESA QUOTAZIONE |
| OPZIONALE | AliExpress | €48.00 | 💡 NON URGENTE |

**TOTALE PROGETTO: €871-1,036** (esclude stampante QIDI già acquistata)

---

## CHECKLIST PRE-ORDINE:

### VERIFICA CARRELLO AMAZON.IT:
- [ ] 6 prodotti filamenti + heat set inserts già presenti
- [ ] Aggiungi 17 componenti dalla lista sopra
- [ ] Controlla che TUTTI i link siano corretti
- [ ] Verifica che UBEC 7.4V sia effettivamente 7.4V e NON 5V
- [ ] Verifica che BMS sia 20A e NON 10A

### AZIONI PARALLELE:
- [ ] Email a Eckstein-shop.de per quotazione STS3215
- [ ] Ordina Raspberry Pi Zero 2W da Melopero
- [ ] Ordina batterie Molicel da TheBatteryShop.eu
- [ ] Ordina AI Camera + BNO085 da Pimoroni UK

### DOPO ORDINE:
- [ ] Testa stampante QIDI con filamenti
- [ ] Stampa pezzi di test (supporti, giunti)
- [ ] Verifica heat set inserts con saldatore
- [ ] Attendi risposta Eckstein per ordine finale servos
