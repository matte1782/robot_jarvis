from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

wb = Workbook()
ws = wb.active
ws.title = "AMAZON_IT_ORDER"

# Header
ws['A1'] = 'LISTA ORDINE AMAZON.IT - ORDINA SUBITO'
ws['A1'].font = Font(size=16, bold=True, color='FFFFFF')
ws['A1'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws.merge_cells('A1:G1')
ws.row_dimensions[1].height = 30

# Column headers
headers = ['OK', 'N.', 'Componente', 'Prezzo', 'Link Amazon', 'Note', 'Categoria']
for col, header in enumerate(headers, 1):
    cell = ws.cell(2, col, header)
    cell.font = Font(bold=True, color='FFFFFF')
    cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    cell.alignment = Alignment(horizontal='center', vertical='center')

# Column widths
ws.column_dimensions['A'].width = 5
ws.column_dimensions['B'].width = 5
ws.column_dimensions['C'].width = 50
ws.column_dimensions['D'].width = 12
ws.column_dimensions['E'].width = 25
ws.column_dimensions['F'].width = 45
ws.column_dimensions['G'].width = 15

# Already in cart section
row = 3
ws[f'A{row}'] = "GIA' NEL CARRELLO (verifica):"
ws[f'A{row}'].font = Font(bold=True, size=12)
ws[f'A{row}'].fill = PatternFill(start_color='C6E0B4', end_color='C6E0B4', fill_type='solid')
ws.merge_cells(f'A{row}:G{row}')
row += 1

cart_items = [
    ('✓', '', 'Prusament Galaxy PLA 2x1kg', 75.98, 'Amazon.it', 'Premium structural parts', 'FILAMENTI'),
    ('✓', '', 'Polymaker PLA Pro 1kg', 37.99, 'Amazon.it', 'Engineering-grade', 'FILAMENTI'),
    ('✓', '', 'eSUN PLA+ 1kg', 21.59, 'Amazon.it', 'Standard reliable PLA', 'FILAMENTI'),
    ('✓', '', 'SUNLU Silk Triplo Nero-Oro-Viola 1kg', 18.99, 'Amazon.it', 'Aesthetic premium', 'FILAMENTI'),
    ('✓', '', 'JAYO TPU 95A 0.5kg', 15.99, 'Amazon.it', 'Flexible feet pads', 'FILAMENTI'),
    ('✓', '', 'ruthex M3 Heat Set Inserts 100pcs', 10.99, 'Amazon.it', 'M3x5.7x4mm VERIFICATO', 'HARDWARE'),
]

for item in cart_items:
    for col, value in enumerate(item, 1):
        cell = ws.cell(row, col, value)
        if col == 1:
            cell.alignment = Alignment(horizontal='center')
        elif col == 4:
            cell.number_format = '#,##0.00'
    ws.cell(row, 1).fill = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')
    row += 1

# Subtotal cart
ws[f'C{row}'] = 'Subtotale carrello:'
ws[f'C{row}'].font = Font(bold=True)
ws[f'D{row}'] = f'=SUM(D4:D{row-1})'
ws[f'D{row}'].number_format = '#,##0.00'
ws[f'D{row}'].font = Font(bold=True)
ws[f'D{row}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
row += 2

# Add to cart section
ws[f'A{row}'] = 'AGGIUNGI SUBITO AL CARRELLO:'
ws[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws[f'A{row}'].fill = PatternFill(start_color='C00000', end_color='C00000', fill_type='solid')
ws.merge_cells(f'A{row}:G{row}')
row += 1

new_items = [
    ('', 1, 'SanDisk Ultra 32GB microSD Class 10', 8.00, 'amazon.it/dp/B073K14CVB', 'OS storage - A1 rated', 'STORAGE'),
    ('', 2, 'TTLinker 3.3V-5V Level Shifter', 10.00, 'amazon.it/dp/B07RDHR315', 'Se servos 5V TTL logic', 'ELECTRONICS'),
    ('', 3, 'UBEC 7.4V 10A Step-Down (SERVOS)', 25.00, 'amazon.it/dp/B07K8RQQ8V', 'CRITICO - 7.4V richiesto!', 'POWER'),
    ('', 4, 'UBEC 5V 3A Step-Down (Electronics)', 8.00, 'amazon.it/dp/B08CNDHSP7', 'Rail separato RPi+sensori', 'POWER'),
    ('', 5, '2S BMS 20A with Protection', 12.00, 'amazon.it/dp/B07YZBF8KC', 'CRITICO - 20A richiesto', 'POWER'),
    ('', 6, 'XT30 Connectors Male+Female 5 pairs', 8.00, 'amazon.it/dp/B07PQKJ7HL', 'Power distribution 30A', 'POWER'),
    ('', 7, 'HC-SR04 Ultrasonic Distance Sensor', 3.00, 'amazon.it/dp/B07TKVPHJZ', 'Obstacle detection', 'SENSORS'),
    ('', 8, 'Jumper Wire Kit 120pcs M-F/M-M/F-F', 8.00, 'amazon.it/dp/B01EV70C78', 'Sensor wiring Dupont', 'WIRING'),
    ('', 9, 'Servo Extension Cable 30cm 10pcs', 12.00, 'amazon.it/dp/B07MCXD7SN', 'Wiring servos JR plug', 'WIRING'),
    ('', 10, 'M2/M2.5/M3 Screw Assortment 1080pcs', 15.00, 'amazon.it/dp/B07VNTTTQQ', 'Socket head stainless', 'HARDWARE'),
    ('', 11, 'M3 Ball Bearings 10pcs MR63ZZ', 8.00, 'amazon.it/dp/B07K36M4QX', '3x6x2.5mm low friction', 'HARDWARE'),
    ('', 12, 'Pi Zero Camera Cable 15cm', 5.00, 'amazon.it/dp/B07SMGFT3Y', 'Flexible ribbon cable', 'CAMERA'),
    ('', 13, 'MG90S Metal Gear Servo 13g (4pcs)', 16.00, 'amazon.it/dp/B07MLR1498', 'Per 2DOF arm joints', 'ARMS'),
    ('', 14, 'Servo Extension Cable 15cm 8pcs', 8.00, 'amazon.it/dp/B07MCXD7SN', 'Wiring arms', 'ARMS'),
    ('', 15, 'Aluminum Servo Horn 25T 4pcs', 6.00, 'amazon.it/dp/B07K5H7QRT', 'Heavy-duty arm horn', 'ARMS'),
    ('', 16, 'Soldering Iron Kit 60W with Stand', 25.00, 'amazon.it/dp/B07XKZVG8Z', 'Power + sensor wiring', 'TOOLS'),
    ('', 17, 'Kapton Tape 20mm x 33m', 8.00, 'amazon.it/dp/B07KPY67QF', 'Heat-resistant insulation', 'TOOLS'),
]

start_new = row + 1
for item in new_items:
    for col, value in enumerate(item, 1):
        cell = ws.cell(row, col, value)
        if col == 1:
            cell.alignment = Alignment(horizontal='center')
        elif col == 4:
            cell.number_format = '#,##0.00'
        # Highlight critical items
        if 'CRITICO' in str(item[5]):
            cell.fill = PatternFill(start_color='FFE699', end_color='FFE699', fill_type='solid')
    row += 1

# Subtotal new
ws[f'C{row}'] = 'Subtotale da aggiungere:'
ws[f'C{row}'].font = Font(bold=True)
ws[f'D{row}'] = f'=SUM(D{start_new}:D{row-1})'
ws[f'D{row}'].number_format = '#,##0.00'
ws[f'D{row}'].font = Font(bold=True)
ws[f'D{row}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
row += 1

# Grand total
ws[f'C{row}'] = 'TOTALE ORDINE AMAZON.IT:'
ws[f'C{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws[f'C{row}'].fill = PatternFill(start_color='C00000', end_color='C00000', fill_type='solid')
ws[f'D{row}'] = f'=D{start_new-2}+D{row-1}'
ws[f'D{row}'].number_format = '#,##0.00'
ws[f'D{row}'].font = Font(bold=True, size=12, color='FFFFFF')
ws[f'D{row}'].fill = PatternFill(start_color='C00000', end_color='C00000', fill_type='solid')

# Other suppliers sheet
ws2 = wb.create_sheet("ALTRI_FORNITORI")
ws2['A1'] = 'ORDINI SEPARATI (NON AMAZON)'
ws2['A1'].font = Font(size=14, bold=True, color='FFFFFF')
ws2['A1'].fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
ws2.merge_cells('A1:F1')

headers2 = ['Fornitore', 'Componente', 'Prezzo', 'Link', 'Note', 'Status']
for col, header in enumerate(headers2, 1):
    cell = ws2.cell(2, col, header)
    cell.font = Font(bold=True, color='FFFFFF')
    cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')

ws2.column_dimensions['A'].width = 20
ws2.column_dimensions['B'].width = 40
ws2.column_dimensions['C'].width = 12
ws2.column_dimensions['D'].width = 35
ws2.column_dimensions['E'].width = 40
ws2.column_dimensions['F'].width = 15

other_orders = [
    ('MELOPERO.COM', 'Raspberry Pi Zero 2W', 26.00, 'melopero.com/shop/raspberry-pi/boards/', 'Primary compute unit', 'DA ORDINARE'),
    ('THEBATTERYSHOP.EU', 'Molicel INR18650-P30B (2x)', 14.00, 'thebatteryshop.eu/Molicel-INR18650', 'VERIFIED - controlla QR', 'DA ORDINARE'),
    ('PIMORONI.UK', 'Raspberry Pi AI Camera IMX500', 70.00, 'shop.pimoroni.com/products/ai-camera', 'On-sensor AI vision', 'DA ORDINARE'),
    ('PIMORONI.UK', 'Adafruit BNO085 9-DOF IMU', 38.00, 'shop.pimoroni.com/products/bno085', 'REPLACES BNO055', 'DA ORDINARE'),
]

row2 = 3
for item in other_orders:
    for col, value in enumerate(item, 1):
        cell = ws2.cell(row2, col, value)
        if col == 3:
            cell.number_format = '#,##0.00'
    row2 += 1

ws2[f'B{row2}'] = 'Subtotale altri fornitori:'
ws2[f'B{row2}'].font = Font(bold=True)
ws2[f'C{row2}'] = f'=SUM(C3:C{row2-1})'
ws2[f'C{row2}'].number_format = '#,##0.00'
ws2[f'C{row2}'].font = Font(bold=True)
ws2[f'C{row2}'].fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')

row2 += 2
ws2[f'A{row2}'] = 'ASPETTA RISPOSTA ECKSTEIN'
ws2[f'A{row2}'].font = Font(bold=True, color='FFFFFF')
ws2[f'A{row2}'].fill = PatternFill(start_color='FFC000', end_color='FFC000', fill_type='solid')
ws2.merge_cells(f'A{row2}:F{row2}')
row2 += 1

ws2.cell(row2, 1, 'ECKSTEIN-SHOP.DE')
ws2.cell(row2, 2, 'Feetech STS3215 Servo 7.4V (16x)')
ws2.cell(row2, 3, 400.00)
ws2.cell(row2, 3).number_format = '#,##0.00'
ws2.cell(row2, 4, 'eckstein-shop.de')
ws2.cell(row2, 5, 'ATTENDI QUOTAZIONE prima ordine')
ws2.cell(row2, 6, 'ATTESA RISPOSTA')
for col in range(1, 7):
    ws2.cell(row2, col).fill = PatternFill(start_color='FFE699', end_color='FFE699', fill_type='solid')

wb.save('AMAZON_IT_SHOPPING_TRACKER.xlsx')
print('Excel tracker creato con successo!')
