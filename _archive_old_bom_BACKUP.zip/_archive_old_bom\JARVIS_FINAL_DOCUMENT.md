# JARVIS FINAL CONSOLIDATED DOCUMENT
## AI Desktop Assistant - Complete Implementation Guide

**Version**: 1.0 | **Date**: 2026-01-10 | **Status**: VERIFIED (HostelReviewer: 5/5 CRITICAL RESOLVED)
**Target**: Windows 11 | **Budget Tiers**: Balanced (€300-600) | Pro (€600-1200)

---

# 1. EXECUTIVE SUMMARY (TL;DR)

## Top 3 Architecture Choices

| Tier | Compute | Cost | Pros | Cons |
|------|---------|------|------|------|
| **Balanced** | Existing PC + USB mic | €150-300 | Zero compute cost, 1-day setup | Depends on PC being on |
| **Pro** | Beelink SER8 dedicated | €600-900 | Always-on, silent, dedicated | Additional mini-PC cost |
| **Ultra** | SER8 + eGPU/Jetson | €1200+ | Fast local LLMs, multimodal | Complexity, cost |

## Best Voice Setup
- **Mic**: RØDE NT-USB Mini (~€117) - studio quality, plug-and-play
- **Budget Alternative**: Fifine K669B (~€35) - surprisingly good
- **Speaker**: Creative Pebble V3 (~€40) or existing speakers

## Best Offline LLM Setup
- **Runtime**: Ollama (Windows native)
- **Model**: Qwen2.5-7B-Instruct (excellent tool calling, 8GB RAM)
- **Fallback**: Mistral 7B or Phi-3 Mini

## Best Claude + MCP Setup
- **Host**: Claude Desktop + Claude Code (subscription-based, no API costs)
- **Integration**: Custom Python MCP servers (filesystem, shell, memory)
- **Config**: `%APPDATA%\Claude\claude_desktop_config.json`

## Top 5 Risks + Mitigations

| # | Risk | Probability | Impact | Mitigation |
|---|------|-------------|--------|------------|
| 1 | Command injection | High | CRITICAL | `shell=False` + strict allowlist |
| 2 | Path traversal | Medium | HIGH | Pre-resolve validation + symlink detection |
| 3 | STT latency | Medium | Medium | faster-whisper with GPU, chunking |
| 4 | Claude rate limits | Medium | Medium | Fallback to local LLM, caching |
| 5 | Privacy (always-on) | Medium | High | Push-to-talk only, no cloud STT |

---

# 2. BILL OF MATERIALS (EU/ITALY SOURCING)

## Balanced Build (€350-500)

| Component | Selected Item | Price EUR | EU Source |
|-----------|---------------|-----------|-----------|
| Compute | Minisforum UN100P (16GB/512GB) | 220 | Amazon.it |
| Microphone | Fifine K669B | 35 | Amazon.it |
| Speakers | Creative Pebble Plus | 40 | Amazon.it |
| USB Hub | RSHTECH 7-port | 35 | Amazon.it |
| Mic Arm | Aokeo AK-35 | 20 | Amazon.it |
| **TOTAL** | | **€350** | |

**Optional additions**: UPS (€60), Webcam (€70) → **With all options: €480**

## Pro Build (€750-1000)

| Component | Selected Item | Price EUR | EU Source |
|-----------|---------------|-----------|-----------|
| Compute | Beelink SER8 (32GB/1TB) | 650 | Amazon.it |
| Microphone | RØDE NT-USB Mini | 100 | Thomann.it |
| Speakers | Edifier R1280T | 95 | Amazon.it |
| USB Hub | DIGITUS 7-port | 38 | Amazon.it |
| Mic Arm | TONOR T20LP | 35 | Amazon.it |
| UPS | NJOY Keen 800 | 60 | Amazon.it |
| **TOTAL** | | **€978** | |

**Optional**: Webcam C922 Pro (+€90) → **With all options: €1118**

## Software Requirements (All Free)

| Component | Package | Version | Install Command |
|-----------|---------|---------|-----------------|
| Python | Python | 3.11+ | `winget install Python.Python.3.11` |
| MCP SDK | mcp | 1.0+ | `pip install mcp` |
| Windows Utils | pywin32 | Latest | `pip install pywin32` |
| Anthropic SDK | anthropic | 0.34+ | `pip install anthropic` |
| STT | faster-whisper | 1.0+ | `pip install faster-whisper` |
| TTS | edge-tts | 6.1+ | `pip install edge-tts` |
| Hotkey | pynput | 1.7+ | `pip install pynput` |
| Local LLM | Ollama | Latest | `winget install Ollama.Ollama` |

---

# 3. ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           JARVIS V1 ARCHITECTURE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌────────────────┐                      ┌─────────────────┐                │
│   │   USER INPUT   │                      │   USER OUTPUT   │                │
│   │                │                      │                 │                │
│   │  ┌──────────┐  │                      │  ┌───────────┐  │                │
│   │  │ MIC USB  │  │                      │  │ SPEAKERS  │  │                │
│   │  │ (RØDE)   │  │                      │  │ (Edifier) │  │                │
│   │  └────┬─────┘  │                      │  └─────▲─────┘  │                │
│   └───────┼────────┘                      └───────┼─────────┘                │
│           │                                       │                          │
│           ▼                                       │                          │
│   ┌───────────────┐                      ┌────────┴────────┐                 │
│   │  STT LOCAL    │                      │   TTS LOCAL     │                 │
│   │ faster-whisper│                      │   edge-tts      │                 │
│   │ ~500ms latency│                      │  ~300ms latency │                 │
│   └───────┬───────┘                      └────────▲────────┘                 │
│           │                                       │                          │
│           ▼                                       │                          │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                           JARVIS CORE (Python)                       │   │
│   │                                                                      │   │
│   │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐      │   │
│   │  │  Voice Pipeline │  │   LLM Router    │  │   Auth + Rate   │      │   │
│   │  │  (pynput PTT)   │  │ Claude ↔ Ollama │  │     Limiter     │      │   │
│   │  └────────┬────────┘  └────────┬────────┘  └─────────────────┘      │   │
│   │           │                    │                                     │   │
│   └───────────┼────────────────────┼─────────────────────────────────────┘   │
│               │                    │                                         │
│               ▼                    ▼                                         │
│   ┌───────────────────────────────────────────────────────────────────────┐ │
│   │                           MCP LAYER (stdio)                            │ │
│   │                                                                        │ │
│   │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │ │
│   │   │  Filesystem  │  │    Shell     │  │   Memory     │               │ │
│   │   │   Server     │  │   Server     │  │   Server     │               │ │
│   │   │ (sandboxed)  │  │ (allowlist)  │  │ (Anthropic)  │               │ │
│   │   └──────┬───────┘  └──────┬───────┘  └──────┬───────┘               │ │
│   │          │                 │                 │                        │ │
│   └──────────┼─────────────────┼─────────────────┼────────────────────────┘ │
│              │                 │                 │                          │
│              ▼                 ▼                 ▼                          │
│   ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐       │
│   │   ~/jarvis/      │   │ Allowed Commands │   │    memory.jsonl  │       │
│   │   workspace/     │   │ git, dir, pip... │   │   (persistent)   │       │
│   └──────────────────┘   └──────────────────┘   └──────────────────┘       │
│                                                                              │
│   ┌────────────────────────────────────────────────────────────────────┐    │
│   │                         LLM BACKENDS                                │    │
│   │                                                                     │    │
│   │  ┌───────────────────┐              ┌───────────────────┐          │    │
│   │  │   CLAUDE DESKTOP  │◄── hybrid ──►│   OLLAMA LOCAL    │          │    │
│   │  │   (via MCP)       │    routing   │  (qwen2.5:7b)     │          │    │
│   │  │   subscription    │              │   offline         │          │    │
│   │  └───────────────────┘              └───────────────────┘          │    │
│   │                                                                     │    │
│   └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 4. SECURITY MODEL

## 4.1 Threat Model Summary

| Threat | Risk Level | Mitigation | Status |
|--------|------------|------------|--------|
| **Command Injection** | CRITICAL | `shell=False`, character blocking | ✅ IMPLEMENTED |
| **Path Traversal** | HIGH | Pre-resolve + symlink detection | ✅ IMPLEMENTED |
| **Python -c Execution** | CRITICAL | Removed from allowlist | ✅ IMPLEMENTED |
| **API Key Exposure** | HIGH | SHA-256 hashing, sanitized logs | ✅ IMPLEMENTED |
| **Voice Spoofing** | MEDIUM | Push-to-talk only (F9 key) | ✅ IMPLEMENTED |
| **Rate Limiting Bypass** | MEDIUM | Sliding window, per-client | ✅ IMPLEMENTED |
| **Symlink Attack** | HIGH | Check is_symlink() on all paths | ✅ IMPLEMENTED |

## 4.2 Security Defaults

```python
# filesystem_server.py
MAX_READ_SIZE = 10 * 1024 * 1024   # 10 MB
MAX_WRITE_SIZE = 5 * 1024 * 1024   # 5 MB
MAX_PATH_LENGTH = 500              # chars
RATE_LIMIT = 100 requests/60s

# shell_server.py
shell=False                        # CRITICAL: Never shell=True
MAX_TIMEOUT = 120                  # seconds
DANGEROUS_CHARS = [";", "&&", "|", "`", "$(", ">", "<", "\n"]

# voice_pipeline.py
PUSH_TO_TALK_KEY = keyboard.Key.f9  # Physical key required
DELETE_AUDIO_IMMEDIATELY = True     # No persistence
```

## 4.3 Security Checklist (Pre-Deployment)

- [x] `shell=False` for all subprocess calls
- [x] `python -c` NOT in command allowlist
- [x] Path traversal protection with symlink detection
- [x] File operations restricted to workspace
- [x] API keys hashed with SHA-256
- [x] Constant-time comparison for auth
- [x] Rate limiting on all endpoints
- [x] Sanitized error messages
- [x] Push-to-talk mode only
- [x] Audit logging enabled

---

# 5. OFFLINE VIABILITY

## 5.1 Ollama Setup

```powershell
# Install Ollama
winget install Ollama.Ollama

# Pull recommended model
ollama pull qwen2.5:7b

# Verify API
curl http://localhost:11434/api/tags
```

## 5.2 Model Recommendations by Hardware

| RAM | GPU VRAM | Recommended Model | Performance |
|-----|----------|-------------------|-------------|
| 16GB | None | qwen2.5:7b Q4 | 12-15 t/s (CPU) |
| 16GB | 8GB | qwen2.5:7b Q4 | 45-52 t/s (GPU) |
| 32GB | 12GB | qwen2.5:14b Q4 | 35-40 t/s (GPU) |
| 32GB | 24GB | qwen2.5:32b Q4 | 40-50 t/s (GPU) |

## 5.3 Routing Strategy

| Condition | Route To | Reason |
|-----------|----------|--------|
| No internet | Ollama | Only option |
| Privacy-sensitive data | Ollama | Data stays local |
| Simple Q&A | Ollama | Save Claude quota |
| Complex reasoning | Claude | Better quality |
| Code review/debugging | Claude | Better analysis |

## 5.4 Offline Feature Matrix

| Feature | Online | Offline | Notes |
|---------|--------|---------|-------|
| Voice Input (STT) | ✅ | ✅ | faster-whisper is local |
| Voice Output (TTS) | ✅ | ⚠️ | edge-tts needs internet; fallback to pyttsx3 |
| Chat/Reasoning | ✅ | ✅ | Ollama qwen2.5:7b |
| Coding Assistance | ✅ | ✅ | Qwen excellent for code |
| File Operations | ✅ | ✅ | Fully local |
| Shell Commands | ✅ | ✅ | Fully local |
| Memory/Context | ✅ | ✅ | Local JSONL file |

---

# 6. MCP INTEGRATION

## 6.1 Claude Desktop Configuration

**Location**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "globalShortcut": "Alt+C",
  "mcpServers": {
    "jarvis-filesystem": {
      "command": "python",
      "args": ["C:\\path\\to\\robot_jarvis\\mcp_servers\\filesystem_server.py"],
      "env": {
        "JARVIS_WORKSPACE": "C:\\Users\\YOUR_USERNAME\\jarvis\\workspace"
      }
    },
    "jarvis-shell": {
      "command": "python",
      "args": ["C:\\path\\to\\robot_jarvis\\mcp_servers\\shell_server.py"]
    },
    "jarvis-memory": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-memory"],
      "env": {
        "MEMORY_FILE_PATH": "C:\\Users\\YOUR_USERNAME\\jarvis\\memory.jsonl"
      }
    }
  }
}
```

## 6.2 MCP Servers Implemented

| Server | Tools | Security Features |
|--------|-------|-------------------|
| **filesystem_server.py** | read_file, write_file, list_directory, delete_file | Path traversal protection, symlink detection, size limits |
| **shell_server.py** | run_command, list_allowed_commands | shell=False, strict allowlist, no python -c |
| **memory (official)** | create_entities, search_nodes, read_graph | Anthropic's official implementation |

## 6.3 Verification

```powershell
# 1. Check MCP SDK
python -c "from mcp.server import Server; print('MCP OK')"

# 2. Check pywin32
python -c "import win32api; print('pywin32 OK')"

# 3. Restart Claude Desktop and look for hammer icon

# 4. Test: "What MCP tools do you have access to?"
```

---

# 7. VOICE PIPELINE

## 7.1 Technology Stack

| Component | Technology | Latency | Notes |
|-----------|------------|---------|-------|
| **STT** | faster-whisper (base) | ~500ms | Local, GPU-accelerated if available |
| **TTS** | edge-tts | ~300ms | Cloud (Microsoft), high quality voices |
| **Hotkey** | pynput | Instant | No admin required (unlike keyboard lib) |
| **Audio I/O** | sounddevice + pyaudio | ~50ms | Low-level audio access |

## 7.2 Push-to-Talk Implementation

```python
from pynput import keyboard

PUSH_TO_TALK_KEY = keyboard.Key.f9

def on_press(key):
    if key == PUSH_TO_TALK_KEY:
        start_recording()

def on_release(key):
    if key == PUSH_TO_TALK_KEY:
        stop_recording()
        process_audio()

listener = keyboard.Listener(on_press=on_press, on_release=on_release)
listener.start()
```

## 7.3 TTS Voices

```python
# English voices
TTS_VOICE = "en-US-GuyNeural"      # Male, American
TTS_VOICE = "en-GB-RyanNeural"     # Male, British

# Italian voices
TTS_VOICE = "it-IT-DiegoNeural"    # Male, Italian
TTS_VOICE = "it-IT-ElsaNeural"     # Female, Italian
```

---

# 8. DAILY WORKFLOWS

## 8.1 Morning Routine
```
User: "Good morning JARVIS"
JARVIS: Here's your day:
        - 3 meetings scheduled
        - 5 tasks pending (2 high priority)
        - 1 PR awaiting review
```

## 8.2 PR Helper
```
User: "Generate a PR description for my changes"
JARVIS: [Calls git log, git diff, analyzes changes]
        ## Summary
        Refactored authentication module to use SHA-256 hashing

        ## Changes Made
        - Updated auth.py with secure key hashing
        - Added rate limiting tests
        ...
```

## 8.3 Debug Buddy
```
User: "I'm getting this error: TypeError: 'NoneType' has no attribute 'split'"
JARVIS: [Analyzes traceback, reads source file]
        ## Error Analysis
        Location: src/parser.py:45
        Issue: user.name is None when user not found

        ## Suggested Fix
        if user and user.name:
            parts = user.name.split()
```

---

# 9. V3 ROBOT INTEGRATION ROADMAP

## 9.1 Architecture

```
JARVIS Core (Mini-PC)                    Robot Client (Pi Zero 2W)
┌─────────────────────┐                  ┌─────────────────────┐
│  LLM + STT + TTS    │◄── WebSocket ──►│  MIC + Speaker +    │
│  (all processing)   │    WiFi LAN      │  Camera + LEDs      │
└─────────────────────┘                  │  (I/O only)         │
                                         └─────────────────────┘
```

## 9.2 Open Duck Mini BOM (EUR 183-317 self-build)

| Category | Components | Est. Cost |
|----------|------------|-----------|
| Mechanical | 3D printed parts | €20-50 |
| Electronics | Pi Zero 2W, IMU, PCB | €60-80 |
| Servos | 14x Feetech/MG90S | €35-70 |
| Audio | INMP441 + MAX98357 | €15-25 |
| Vision | OV5647 camera | €10-25 |
| LEDs | WS2812B (eyes) | €8-12 |
| Power | LiPo 2S + charger | €15-25 |
| Misc | Wiring, connectors | €20-30 |

## 9.3 Privacy Considerations

- Push-to-talk button on robot
- LED indicator when mic active
- Camera only on explicit request
- All processing on JARVIS Core (not robot)
- No cloud audio streaming

---

# 10. QUICK-START INSTALLATION

## Step 1: Prerequisites

```powershell
# Python 3.11+
winget install Python.Python.3.11

# Node.js (for npx MCP servers)
winget install OpenJS.NodeJS.LTS

# Ollama
winget install Ollama.Ollama
```

## Step 2: Install Dependencies

```powershell
cd robot_jarvis
pip install mcp pywin32 anthropic pydantic python-dotenv
pip install faster-whisper edge-tts pynput sounddevice
```

## Step 3: Configure Environment

```powershell
# Copy and edit .env
copy .env.example .env
notepad .env

# Set JARVIS_WORKSPACE and your username
```

## Step 4: Configure Claude Desktop

```powershell
# Copy config
copy config\claude_desktop_config.example.json "%APPDATA%\Claude\claude_desktop_config.json"

# Edit with your paths
notepad "%APPDATA%\Claude\claude_desktop_config.json"
```

## Step 5: Create Workspace

```powershell
mkdir C:\Users\%USERNAME%\jarvis\workspace
```

## Step 6: Pull Ollama Model

```powershell
ollama pull qwen2.5:7b
```

## Step 7: Restart Claude Desktop

- Quit completely
- Reopen
- Look for hammer icon 🔨

## Step 8: Verify

```powershell
# In Claude Desktop, type:
"List my available MCP tools"

# Expected: filesystem tools, shell tools, memory tools
```

---

# VERIFICATION SUMMARY

## HostelReviewer Final Verification: ✅ PASSED

| Critical Defect | Status | Evidence |
|-----------------|--------|----------|
| CRITICAL-001: anthropic-sdk → anthropic | ✅ FIXED | requirements.txt, BUILD_GUIDE |
| CRITICAL-002: shell=True → shell=False | ✅ FIXED | shell_server.py:467, BUILD_GUIDE:670 |
| CRITICAL-003: keyboard → pynput | ✅ FIXED | voice_pipeline.py:30, requirements.txt |
| CRITICAL-004: piper → edge-tts | ✅ FIXED | voice_pipeline.py, requirements.txt |
| CRITICAL-005: python -c removed | ✅ FIXED | shell_server.py ALLOWED_COMMANDS |

**Result: 5/5 CRITICAL DEFECTS RESOLVED**

---

# DOCUMENT METADATA

| Field | Value |
|-------|-------|
| Version | 1.0 |
| Date | 2026-01-10 |
| Author | JARVIS Research Environment v2 |
| Research Agents | 7 parallel agents (A-G) |
| QA Process | HostelReviewer (2 passes) |
| Status | VERIFIED - Ready for Implementation |

---

**END OF FINAL DOCUMENT**
