# JARVIS: Complete Build Guide
## AI Desktop Assistant with Claude Subscription + Offline LLM

**Version**: 1.0 | **Date**: 2026-01-10 | **Target**: Windows 11
**Budget Tiers**: Balanced (€300-600) | Pro (€600-1200)

---

# 1. TL;DR (Executive Summary)

## Top 3 Architetture "Jarvis Core"

| Tier | Compute | Costo | Pro | Contro |
|------|---------|-------|-----|--------|
| **Balanced** | PC esistente + mic USB | €150-300 | Zero costi compute, setup 1 giorno | Dipende dal PC acceso |
| **Pro** | Beelink SER5 Pro dedicato | €600-900 | Always-on, silenzioso, dedicato | Costo aggiuntivo mini-PC |
| **Ultra** | SER8 + GPU eGPU/Jetson | €1200+ | LLM locali veloci, multimodale | Complessità, costo |

## Best Voice Setup (Qualità/Prezzo)
- **Mic**: RØDE NT-USB Mini (~€117) - qualità studio, plug-and-play
- **Alternativa budget**: Fifine K669B (~€35) - sorprendentemente buono
- **Speaker**: Qualsiasi speaker attivo esistente o Creative Pebble V3 (~€40)

## Best Offline LLM Setup
- **Runtime**: Ollama (Windows native)
- **Modello**: Qwen 2.5 7B (excellent coding, 8GB RAM, matches code default)
- **Alternativa leggera**: Llama 3.1 8B, Mistral 7B o Phi-3 Mini

## Best Claude Subscription + MCP Setup
- **Host**: Claude Desktop + Claude Code
- **Integrazione**: MCP servers locali (Python/TypeScript)
- **Config**: `claude_desktop_config.json` + `.mcp.json`

## Top 5 Rischi + Mitigazioni

| # | Rischio | Probabilità | Impatto | Mitigazione |
|---|---------|-------------|---------|-------------|
| 1 | Latenza STT streaming | Alta | Media | Usare faster-whisper con GPU, chunking ottimizzato |
| 2 | Qualità mic scarsa | Media | Alta | Testare mic in ambiente reale prima di acquisto |
| 3 | Tool execution non-safe | Alta | Critico | Sandbox + allowlist + double-confirm su write ops |
| 4 | Claude rate limits | Media | Media | Fallback a LLM locale, caching risposte |
| 5 | Privacy audio sempre-on | Media | Alto | Push-to-talk default, indicatore LED, no cloud STT |

---

# 2. Architettura

## 2.1 V1 FAST (Day 1-3) - PC Esistente

```
┌─────────────────────────────────────────────────────────────────┐
│                        YOUR WINDOWS PC                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │   MIC USB    │───▶│  STT Local   │───▶│   JARVIS     │      │
│  │  (RØDE Mini) │    │(faster-whsp) │    │    CORE      │      │
│  └──────────────┘    └──────────────┘    │   (Python)   │      │
│                                          │              │      │
│  ┌──────────────┐    ┌──────────────┐    │  ┌────────┐  │      │
│  │   SPEAKER    │◀───│  TTS Local   │◀───│  │ Router │  │      │
│  │  (existing)  │    │ (edge-tts)    │    │  └────────┘  │      │
│  └──────────────┘    └──────────────┘    │      │       │      │
│                                          └──────┼───────┘      │
│                                                 │              │
│         ┌───────────────────────────────────────┼──────┐       │
│         │              MCP LAYER                │      │       │
│         │  ┌─────────┐  ┌─────────┐  ┌─────────┐│      │       │
│         │  │Filesystem│  │  Shell  │  │  Git    ││      │       │
│         │  │ Server   │  │ Server  │  │ Server  ││      │       │
│         │  └─────────┘  └─────────┘  └─────────┘│      │       │
│         └───────────────────────────────────────┘      │       │
│                                                 │              │
│    ┌────────────────┐          ┌────────────────┐              │
│    │ CLAUDE DESKTOP │◀────────▶│  OLLAMA LOCAL  │              │
│    │  (via MCP)     │  hybrid  │  (Qwen 2.5)    │              │
│    │  subscription  │  routing │   offline      │              │
│    └────────────────┘          └────────────────┘              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Protocolli:
- MCP: JSON-RPC over stdio (locale)
- STT: WebSocket interno o pipe
- TTS: file audio + playback
- LLM routing: HTTP localhost:11434 (Ollama)
```

### Componenti V1

| Componente | Tecnologia | Dove gira | Note |
|------------|------------|-----------|------|
| STT | faster-whisper | PC (GPU se disponibile) | ~500ms latency con chunking |
| TTS | edge-tts | PC (cloud) | ~300ms latency, ottime voci IT/EN neurali |
| LLM Cloud | Claude Desktop | PC + cloud | Via MCP, subscription |
| LLM Local | Ollama + Qwen 2.5 7B | PC | Fallback offline |
| MCP Servers | Python/Node | PC | Filesystem, Shell, Git |
| Audio I/O | sounddevice + pyaudio | PC | Push-to-talk hotkey |

### Threat Model V1

| Vettore | Rischio | Mitigazione |
|---------|---------|-------------|
| Voice spoofing | Basso (push-to-talk) | Hotkey fisica richiesta |
| Command injection | Alto | Sandbox shell, allowlist comandi |
| Data exfil | Medio | Filesystem limitato a ~/jarvis_workspace |
| Token leak | Alto | .env con permessi 600, mai in log |
| Recording privacy | Medio | LED indicator, no persistent recording |

---

## 2.2 V2 PRO (Week 2+) - Mini-PC Dedicato

```
┌────────────────────────────────────────────────────────────────────┐
│                    BEELINK SER5 PRO (DEDICATED)                    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────────┐ │
│  │  MIC ARRAY   │───▶│  STT Local   │───▶│     JARVIS CORE      │ │
│  │(ReSpeaker/   │    │(faster-whsp) │    │      (Python)        │ │
│  │ RØDE NT-USB) │    │   + VAD      │    │                      │ │
│  └──────────────┘    └──────────────┘    │  ┌────────────────┐  │ │
│                                          │  │   LLM Router   │  │ │
│  ┌──────────────┐    ┌──────────────┐    │  │                │  │ │
│  │   SPEAKER    │◀───│  TTS Local   │◀───│  │ Claude Online  │  │ │
│  │  (USB/Jack)  │    │ (edge-tts)    │    │  │ Ollama Offline │  │ │
│  └──────────────┘    └──────────────┘    │  └────────────────┘  │ │
│                                          │                      │ │
│  ┌──────────────┐                        │  ┌────────────────┐  │ │
│  │   WEBCAM     │────────────────────────│  │   MCP Layer    │  │ │
│  │ (Logitech)   │    (future v3)         │  │ + Tool Runtime │  │ │
│  └──────────────┘                        │  └────────────────┘  │ │
│                                          └──────────┬───────────┘ │
│                                                     │             │
│  ┌──────────────────────────────────────────────────┼───────────┐ │
│  │                    NETWORK LAYER                 │           │ │
│  │                                                  │           │ │
│  │   ┌─────────────┐    ┌─────────────┐    ┌───────┴─────┐     │ │
│  │   │  n8n/Home   │    │   GitHub    │    │   Claude    │     │ │
│  │   │  Assistant  │    │   API       │    │   Cloud     │     │ │
│  │   └─────────────┘    └─────────────┘    └─────────────┘     │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
         │
         │ WebSocket/MQTT
         ▼
┌────────────────────────────────────────┐
│           YOUR MAIN PC                 │
│   (Claude Code + development)          │
│   Accede a Jarvis via network          │
└────────────────────────────────────────┘
```

### Protocolli V2

| Connessione | Protocollo | Porta | Auth |
|-------------|------------|-------|------|
| Main PC ↔ Jarvis | WebSocket | 8765 | JWT token |
| Jarvis ↔ n8n | HTTP webhook | 5678 | API key |
| Jarvis ↔ Claude | MCP stdio | - | Session |
| Jarvis ↔ Ollama | HTTP | 11434 | localhost only |

---

## 2.3 V3 ROBOT (Month 2+) - Open Duck Mini

```
┌─────────────────────────────────────────────────────────────────────┐
│                         JARVIS CORE                                 │
│                    (Mini-PC / Your PC)                              │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐     │
│  │   LLM Router    │  │   Tool Runtime  │  │   Robot Bridge  │     │
│  │ Claude + Ollama │  │   MCP Servers   │  │   WebSocket     │     │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘     │
│           │                    │                    │              │
│           └────────────────────┼────────────────────┘              │
│                                │                                    │
└────────────────────────────────┼────────────────────────────────────┘
                                 │
                                 │ WebSocket + Audio Stream
                                 │ (WiFi)
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      OPEN DUCK MINI                                 │
│                  (Raspberry Pi Zero 2W)                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌───────────┐  │
│  │  MIC I2S    │  │  SPEAKER    │  │  CAMERA     │  │ LED EYES  │  │
│  │  (INMP441)  │  │  (I2S DAC)  │  │  (OV5647)   │  │ (WS2812)  │  │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └─────┬─────┘  │
│         │                │                │               │        │
│         ▼                ▼                ▼               ▼        │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │              ROBOT CLIENT (Python)                          │   │
│  │   - Audio capture → stream to Jarvis                        │   │
│  │   - Audio playback ← stream from Jarvis                     │   │
│  │   - Camera frames → on-demand to Jarvis                     │   │
│  │   - LED control ← commands from Jarvis                      │   │
│  │   - Motion control (walk/gesture via RL policy)             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                  MOTION CONTROLLER                          │   │
│  │   - 14x servo control (PWM)                                 │   │
│  │   - IMU feedback (BNO055)                                   │   │
│  │   - RL policy inference (tflite)                            │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

Protocol: Robot ↔ Jarvis
┌─────────────────────────────────────────────────────────┐
│  WebSocket JSON Messages                                │
│                                                         │
│  Robot → Jarvis:                                        │
│    { "type": "audio", "data": "<base64 PCM>" }         │
│    { "type": "camera", "data": "<base64 JPEG>" }       │
│    { "type": "imu", "accel": [...], "gyro": [...] }    │
│    { "type": "status", "battery": 85, "temp": 42 }     │
│                                                         │
│  Jarvis → Robot:                                        │
│    { "type": "speak", "audio": "<base64 PCM>" }        │
│    { "type": "led", "pattern": "thinking" }            │
│    { "type": "gesture", "name": "wave" }               │
│    { "type": "walk", "direction": "forward", "steps": 3}│
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

# 3. BOM Completa EU/Italia

## 3.1 TIER BALANCED (€300-600)

### Core Compute (usa PC esistente)
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Nessun acquisto** | Usa PC Windows esistente | - | €0 | - | - | - | Requisiti: 16GB RAM, SSD |

### Audio Input
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **RØDE NT-USB Mini** | Qualità studio, plug-and-play, DSP integrato | 1 | ~€117 | [Amazon.it](https://www.amazon.it/dp/B084P1CXFD) | [RØDE Docs](https://rode.com/en-us/products/nt-usb-mini) | Fifine K669B (~€35), Audio-Technica AT2020USB+ (~€150) | Stock: disponibile |
| **Fifine K669B** (budget alt) | Sorprendentemente buono per il prezzo | 1 | ~€35 | [Amazon.it](https://www.amazon.it/dp/B06XCKGLTP) | - | Tonor TC30 (~€40) | Se budget stretto |

### Audio Output
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Usa speaker esistente** | Qualsiasi speaker PC/cuffie | - | €0 | - | - | - | |
| **Creative Pebble V3** (se serve) | Compatti, USB-C, suono chiaro | 1 | ~€40 | [Amazon.it](https://www.amazon.it/dp/B09571VKK5) | - | Logitech Z150 (~€25) | Opzionale |

### Accessori
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Hub USB 3.0** | Se porte insufficienti | 1 | ~€15 | [Amazon.it](https://www.amazon.it/dp/B07L32B9C2) | - | Qualsiasi hub powered | Solo se serve |

### Software (Gratuito)
| Software | Scopo | Costo | Link |
|----------|-------|-------|------|
| Ollama | LLM locale | Free | https://ollama.com |
| edge-tts | Text-to-speech (Microsoft neural voices) | Free | https://pypi.org/project/edge-tts/ |
| faster-whisper | STT locale | Free | https://github.com/SYSTRAN/faster-whisper |
| Claude Desktop | LLM cloud via MCP | Subscription | https://claude.ai/download |
| Python 3.11+ | Runtime | Free | https://python.org |

**TOTALE TIER BALANCED: €117-170** (solo mic, resto gratis/esistente)

---

## 3.2 TIER PRO (€600-1200)

### Core Compute
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Beelink SER5 Pro** | Ryzen 7 5825U, 16GB, 500GB, silenzioso, always-on | 1 | ~€319 | [Amazon.it](https://www.amazon.it/stores/Beelink/page/C4618949-96C0-48DB-8FF5-83ED0099F0FB) | [Beelink](https://www.bee-link.com) | Beelink SER8 (~€500), Intel NUC 13 (~€450), GMKtec NucBox (~€280) | Coupon -€100 disponibile |
| **RAM upgrade 32GB** (opz) | Per LLM più grandi | 1 | ~€70 | [Amazon.it - DDR4 SODIMM](https://www.amazon.it/s?k=32gb+ddr4+sodimm) | - | Crucial, Kingston, Corsair | Solo se servono modelli 13B+ |

### Audio Input
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **RØDE NT-USB Mini** | Vedi sopra | 1 | ~€117 | [Amazon.it](https://www.amazon.it/dp/B084P1CXFD) | [RØDE](https://rode.com/en-us/products/nt-usb-mini) | Shure MV6 (~€100), Beyerdynamic FOX (~€130) | |
| **Braccio articolato** (opz) | Posizionamento ottimale | 1 | ~€25 | [Amazon.it](https://www.amazon.it/dp/B084WSXZDZ) | - | NEEWER, InnoGear | Incluso in alcuni bundle |

### Audio Output
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Creative Pebble V3** | Compatti, buona qualità vocale | 1 | ~€40 | [Amazon.it](https://www.amazon.it/dp/B09571VKK5) | - | Audioengine A2+ (~€250), Edifier R1280T (~€100) | |

### Video (Opzionale V2)
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Logitech Brio 100** | 1080p, autofocus, privacy shutter | 1 | ~€35 | [Amazon.it](https://www.amazon.it/dp/B0CJR7MZQD) | [Logitech](https://www.logitech.com) | Logitech C920 (~€65), Brio 300 (~€45) | Per future integrazioni vision |

### Storage & Power
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **SSD NVMe 1TB** (se upgrade) | Storage aggiuntivo per modelli LLM | 1 | ~€70 | [Amazon.it](https://www.amazon.it/s?k=nvme+1tb) | - | Samsung 980, WD SN770, Crucial P3 | SER5 Pro ha già 500GB |
| **UPS APC 700VA** | Shutdown graceful, protezione | 1 | ~€80 | [Amazon.it](https://www.amazon.it/dp/B07PLKD5D2) | [APC](https://www.apc.com) | Eaton, CyberPower | Opzionale ma consigliato |

### Network & Cavi
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Cavo Ethernet Cat6 3m** | Connessione stabile al router | 1 | ~€8 | [Amazon.it](https://www.amazon.it/s?k=cat6+3m) | - | Cat5e sufficiente | |
| **HDMI 2.0 (opz)** | Se monitor status | 1 | ~€10 | [Amazon.it](https://www.amazon.it/s?k=hdmi+2.0) | - | - | Solo se display dedicato |

### Display Status (Opzionale)
| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Display 7" touchscreen** | Dashboard status Jarvis | 1 | ~€70 | [Melopero - RPi Touch Display 2](https://www.melopero.com/it/shop/) | - | Waveshare 7", Elecrow 5" | Via HDMI dal mini-PC |

**TOTALE TIER PRO: €600-850** (configurazione tipica ~€700)

---

## 3.3 ROBOT ADD-ON (Open Duck Mini) - Future V3

| Componente | Perché | Qty | Prezzo EU | Link IT | Docs | Alternative | Note |
|------------|--------|-----|-----------|---------|------|-------------|------|
| **Open Duck Mini Kit** | Robot bipede open source | 1 | ~€300-400 | [AIFITLAB](https://aifitlab.com/products/openduckmini-open-source-version-of-the-bdx-droid) | [GitHub](https://github.com/apirrone/Open_Duck_Mini) | Self-print + parts | Kit o self-build |
| **Raspberry Pi Zero 2W** | Brain del robot | 1 | ~€18 | [Melopero](https://www.melopero.com/it/) | [RPi](https://www.raspberrypi.com) | Già incluso in kit | |
| **Servo SG90/MG90S** | Motori articolazioni | 14 | ~€35 tot | [Amazon.it](https://www.amazon.it/s?k=mg90s+servo) | - | Feetech FS90 | 14 pezzi necessari |
| **IMU BNO055** | Orientamento/balance | 1 | ~€30 | [Melopero](https://www.melopero.com/it/) | [Bosch](https://www.bosch-sensortec.com) | MPU6050 (~€5, meno preciso) | |
| **Mic I2S INMP441** | Audio input robot | 1 | ~€5 | [Amazon.it](https://www.amazon.it/s?k=inmp441) | - | SPH0645 | |
| **Speaker I2S MAX98357** | Audio output robot | 1 | ~€8 | [Amazon.it](https://www.amazon.it/s?k=max98357) | - | - | Con piccolo speaker |
| **Camera OV5647** | Eyes del robot | 1 | ~€15 | [Melopero](https://www.melopero.com/it/) | - | RPi Camera Module 3 (~€25) | |
| **LED WS2812B** | Espressioni occhi | 10 | ~€8 | [Amazon.it](https://www.amazon.it/s?k=ws2812b+led) | - | NeoPixel ring | |
| **LiPo 2S 1000mAh** | Alimentazione | 1 | ~€15 | [Amazon.it](https://www.amazon.it/s?k=lipo+2s+1000mah) | - | - | Con charger |
| **Filamento PLA 1kg** | Stampa 3D parti | 1 | ~€20 | [Amazon.it](https://www.amazon.it/s?k=pla+filament) | - | PETG per più resistenza | Se self-print |

**TOTALE ROBOT ADD-ON: €400-550** (self-build) o **€300-400** (kit pre-assemblato)

---

## 3.4 Rivenditori EU/IT Raccomandati

| Rivenditore | Specialità | Spedizione IT | Link |
|-------------|------------|---------------|------|
| **Amazon.it** | Tutto, veloce | 1-2 giorni Prime | https://amazon.it |
| **Melopero** | Raspberry Pi, sensori, maker | 2-4 giorni | https://melopero.com |
| **Robot Italy** | Robotica, Arduino | 3-5 giorni | https://robot-italy.com |
| **Reichelt** | Elettronica, componenti | 4-7 giorni | https://reichelt.com |
| **RS Components** | Pro/industrial | 2-3 giorni | https://it.rs-online.com |
| **Mouser EU** | Componenti elettronici | 3-5 giorni | https://mouser.it |
| **Conrad** | Elettronica consumer | 3-5 giorni | https://conrad.it |

---

# 4. Guida Step-by-Step "Simple Build"

## Day 0: Prerequisiti

### Checklist Hardware
- [ ] PC Windows 11 con 16GB+ RAM
- [ ] SSD con almeno 50GB liberi
- [ ] Connessione internet stabile
- [ ] (Opzionale) GPU NVIDIA per STT veloce

### Checklist Software
```powershell
# Verifica Python
python --version  # Deve essere 3.11+

# Se non installato:
winget install Python.Python.3.11

# Verifica Git
git --version

# Se non installato:
winget install Git.Git

# Verifica Node.js (per MCP TypeScript)
node --version  # Deve essere 18+

# Se non installato:
winget install OpenJS.NodeJS.LTS
```

### Installa Claude Desktop
1. Vai su https://claude.ai/download
2. Scarica e installa Claude Desktop per Windows
3. Fai login con il tuo account Claude (subscription)
4. Verifica che funzioni aprendo una chat

### Installa Ollama
```powershell
# Download e installa da https://ollama.com/download/windows

# Dopo installazione, verifica:
ollama --version

# Pull del modello base per tool calling:
ollama pull llama3.1:8b

# Verifica che funzioni:
ollama run llama3.1:8b "Ciao, dimmi una cosa interessante"
# Ctrl+D per uscire
```

**Check di successo Day 0:**
- [ ] `python --version` → 3.11+
- [ ] `ollama run llama3.1:8b` risponde
- [ ] Claude Desktop aperto e funzionante

---

## Day 1: Setup Base + Primo MCP Tool

### Step 1.1: Crea struttura progetto

```powershell
# Crea directory di lavoro
mkdir C:\Users\$env:USERNAME\jarvis
cd C:\Users\$env:USERNAME\jarvis

# Crea struttura
mkdir src, config, logs, workspace, mcp_servers

# Crea virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Installa dipendenze base
pip install mcp pywin32 anthropic pydantic python-dotenv
```

### Step 1.2: Crea primo MCP Server (Filesystem)

Crea file `mcp_servers/filesystem_server.py`:

```python
"""
Jarvis Filesystem MCP Server
Safe file operations within workspace directory only
"""
import os
import json
from pathlib import Path
from mcp.server import Server
from mcp.types import Tool, TextContent

# SECURITY: Only allow operations in workspace
WORKSPACE = Path(os.environ.get("JARVIS_WORKSPACE", Path.home() / "jarvis" / "workspace"))
WORKSPACE.mkdir(parents=True, exist_ok=True)

server = Server("jarvis-filesystem")

def safe_path(path: str) -> Path:
    """Ensure path is within workspace"""
    resolved = (WORKSPACE / path).resolve()
    if not str(resolved).startswith(str(WORKSPACE.resolve())):
        raise ValueError(f"Path escapes workspace: {path}")
    return resolved

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="read_file",
            description="Read contents of a file in workspace",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path within workspace"}
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="write_file",
            description="Write content to a file in workspace (requires confirmation)",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path within workspace"},
                    "content": {"type": "string", "description": "Content to write"}
                },
                "required": ["path", "content"]
            }
        ),
        Tool(
            name="list_directory",
            description="List files in a directory within workspace",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path within workspace", "default": "."}
                }
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    try:
        if name == "read_file":
            path = safe_path(arguments["path"])
            if not path.exists():
                return [TextContent(type="text", text=f"Error: File not found: {arguments['path']}")]
            content = path.read_text(encoding="utf-8")
            return [TextContent(type="text", text=content)]

        elif name == "write_file":
            path = safe_path(arguments["path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(arguments["content"], encoding="utf-8")
            return [TextContent(type="text", text=f"Successfully wrote to {arguments['path']}")]

        elif name == "list_directory":
            path = safe_path(arguments.get("path", "."))
            if not path.exists():
                return [TextContent(type="text", text=f"Error: Directory not found")]
            items = [f"{'[DIR]' if p.is_dir() else '[FILE]'} {p.name}" for p in path.iterdir()]
            return [TextContent(type="text", text="\n".join(items) if items else "(empty)")]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]

if __name__ == "__main__":
    import asyncio
    from mcp.server.stdio import stdio_server

    async def main():
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    asyncio.run(main())
```

### Step 1.3: Configura Claude Desktop per MCP

Trova il file di config di Claude Desktop:
```powershell
# Il file è in:
# %APPDATA%\Claude\claude_desktop_config.json

notepad $env:APPDATA\Claude\claude_desktop_config.json
```

Aggiungi la configurazione MCP:

```json
{
  "mcpServers": {
    "jarvis-filesystem": {
      "command": "python",
      "args": ["C:\\Users\\YOUR_USERNAME\\jarvis\\mcp_servers\\filesystem_server.py"],
      "env": {
        "JARVIS_WORKSPACE": "C:\\Users\\YOUR_USERNAME\\jarvis\\workspace"
      }
    }
  }
}
```

**IMPORTANTE**: Sostituisci `YOUR_USERNAME` con il tuo username Windows!

### Step 1.4: Testa MCP in Claude Desktop

1. Chiudi completamente Claude Desktop
2. Riapri Claude Desktop
3. Guarda in basso a destra: dovresti vedere l'icona 🔨 (tools)
4. Clicca sull'icona per vedere "jarvis-filesystem" attivo

Ora prova in chat:
```
Elenca i file nella mia workspace di Jarvis
```

Claude dovrebbe usare il tool `list_directory` e mostrarti il contenuto.

Prova anche:
```
Crea un file "test.txt" nella workspace con scritto "Hello Jarvis!"
```

**Check di successo Step 1:**
- [ ] Icona 🔨 visibile in Claude Desktop
- [ ] Tool `list_directory` funziona
- [ ] Tool `write_file` crea file in workspace

### Step 1.5: Aggiungi MCP Server per Shell (Safe Mode)

Crea file `mcp_servers/shell_server.py`:

```python
"""
Jarvis Shell MCP Server
SAFE mode: only allowlisted read-only commands
"""
import subprocess
import shlex
from mcp.server import Server
from mcp.types import Tool, TextContent

server = Server("jarvis-shell")

# SECURITY: Allowlist of safe commands
ALLOWED_COMMANDS = {
    "git": ["status", "diff", "log", "branch", "remote", "show"],
    "dir": [],  # Windows dir
    "type": [],  # Windows cat equivalent
    "where": [],  # Windows which
    "systeminfo": [],
    "tasklist": [],
    "python": ["--version"],
    "node": ["--version"],
    "npm": ["list", "--version"],
    "ollama": ["list", "ps"],
}

def is_safe_command(cmd: str) -> tuple[bool, str]:
    """Check if command is in allowlist"""
    parts = shlex.split(cmd, posix=False)
    if not parts:
        return False, "Empty command"

    base_cmd = parts[0].lower()

    if base_cmd not in ALLOWED_COMMANDS:
        return False, f"Command '{base_cmd}' not in allowlist. Allowed: {list(ALLOWED_COMMANDS.keys())}"

    allowed_subcommands = ALLOWED_COMMANDS[base_cmd]
    if allowed_subcommands and len(parts) > 1:
        if parts[1].lower() not in allowed_subcommands:
            return False, f"Subcommand '{parts[1]}' not allowed for '{base_cmd}'. Allowed: {allowed_subcommands}"

    return True, "OK"

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="run_safe_command",
            description=f"Run a safe shell command. Allowed commands: {list(ALLOWED_COMMANDS.keys())}",
            inputSchema={
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The command to run"},
                    "cwd": {"type": "string", "description": "Working directory (optional)"}
                },
                "required": ["command"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "run_safe_command":
        cmd = arguments["command"]
        cwd = arguments.get("cwd")

        is_safe, reason = is_safe_command(cmd)
        if not is_safe:
            return [TextContent(type="text", text=f"BLOCKED: {reason}")]

        try:
            # SECURITY: Use shell=False with argument list
            args = shlex.split(cmd, posix=False)
            result = subprocess.run(
                args,
                shell=False,  # CRITICAL: Never use shell=True
                capture_output=True,
                text=True,
                timeout=30,
                cwd=cwd
            )
            output = result.stdout + result.stderr
            return [TextContent(type="text", text=output if output else "(no output)")]
        except subprocess.TimeoutExpired:
            return [TextContent(type="text", text="Error: Command timed out (30s)")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {str(e)}")]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]

if __name__ == "__main__":
    import asyncio
    from mcp.server.stdio import stdio_server

    async def main():
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    asyncio.run(main())
```

Aggiungi a `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "jarvis-filesystem": {
      "command": "python",
      "args": ["C:\\Users\\YOUR_USERNAME\\jarvis\\mcp_servers\\filesystem_server.py"],
      "env": {
        "JARVIS_WORKSPACE": "C:\\Users\\YOUR_USERNAME\\jarvis\\workspace"
      }
    },
    "jarvis-shell": {
      "command": "python",
      "args": ["C:\\Users\\YOUR_USERNAME\\jarvis\\mcp_servers\\shell_server.py"]
    }
  }
}
```

**Check di successo Day 1:**
- [ ] 2 MCP servers attivi in Claude Desktop
- [ ] `git status` funziona via tool
- [ ] Comandi pericolosi (es. `rm`, `del`) sono bloccati

---

## Day 2: Voice Pipeline + Memoria

### Step 2.1: Installa faster-whisper per STT

```powershell
cd C:\Users\$env:USERNAME\jarvis
.\.venv\Scripts\Activate.ps1

# Installa faster-whisper
pip install faster-whisper

# Se hai GPU NVIDIA, installa anche CUDA support:
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Test rapido
python -c "from faster_whisper import WhisperModel; print('OK')"
```

### Step 2.2: Installa Piper TTS

```powershell
# Piper per Windows richiede WSL oppure binari pre-compilati
# Opzione semplice: usa il pacchetto Python

pip install piper-tts

# Scarica modello italiano (o inglese)
# I modelli sono su: https://github.com/rhasspy/piper/releases

# Per italiano, scarica:
# - it_IT-riccardo-x_low.onnx
# - it_IT-riccardo-x_low.onnx.json

mkdir models\piper
# Scarica manualmente da https://huggingface.co/rhasspy/piper-voices/tree/main/it/it_IT/riccardo/x_low
```

### Step 2.3: Crea Voice Pipeline

Crea file `src/voice_pipeline.py`:

```python
"""
Jarvis Voice Pipeline
STT (faster-whisper) + TTS (edge-tts) + Push-to-talk

IMPORTANT: Uses pynput instead of keyboard (no admin required)
           Uses edge-tts instead of piper (piper was archived Oct 2025)
"""
import os
import sys
import wave
import tempfile
import threading
import asyncio
from pynput import keyboard  # pip install pynput (no admin required!)
import sounddevice as sd  # pip install sounddevice
import numpy as np
from pathlib import Path
from faster_whisper import WhisperModel
import edge_tts  # pip install edge-tts

class VoicePipeline:
    def __init__(
        self,
        whisper_model: str = "base",  # tiny, base, small, medium, large-v3
        tts_voice: str = "en-US-GuyNeural",  # edge-tts voice
        sample_rate: int = 16000,
    ):
        print("Initializing Voice Pipeline...")

        # STT
        print(f"Loading Whisper model: {whisper_model}")
        self.stt = WhisperModel(whisper_model, device="cpu", compute_type="int8")

        # TTS (edge-tts - free Microsoft neural voices)
        self.tts_voice = tts_voice
        print(f"TTS voice: {tts_voice}")

        self.hotkey = keyboard.Key.f9  # F9 for push-to-talk (no admin needed)
        self.sample_rate = sample_rate
        self.is_recording = False
        self.audio_buffer = []

        print(f"Voice Pipeline ready. Push-to-talk: {hotkey}")

    def start_recording(self):
        """Called when hotkey is pressed"""
        if self.is_recording:
            return

        self.is_recording = True
        self.audio_buffer = []
        print("🎤 Recording... (release hotkey to stop)")

        def audio_callback(indata, frames, time, status):
            if self.is_recording:
                self.audio_buffer.append(indata.copy())

        self.stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype=np.int16,
            callback=audio_callback
        )
        self.stream.start()

    def stop_recording(self) -> str:
        """Called when hotkey is released, returns transcription"""
        if not self.is_recording:
            return ""

        self.is_recording = False
        self.stream.stop()
        self.stream.close()
        print("⏹️ Processing...")

        if not self.audio_buffer:
            return ""

        # Combine audio chunks
        audio = np.concatenate(self.audio_buffer, axis=0)

        # Save to temp file for Whisper
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            with wave.open(f.name, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)  # 16-bit
                wf.setframerate(self.sample_rate)
                wf.writeframes(audio.tobytes())
            temp_path = f.name

        # Transcribe
        segments, info = self.stt.transcribe(temp_path, language="it")  # or "en"
        text = " ".join([s.text for s in segments]).strip()

        # Cleanup
        os.unlink(temp_path)

        print(f"📝 Transcribed: {text}")
        return text

    def speak(self, text: str):
        """Convert text to speech using edge-tts and play"""
        print(f"🔊 Speaking: {text[:50]}...")

        async def _speak():
            communicate = edge_tts.Communicate(text, self.tts_voice)
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                await communicate.save(f.name)
                # Play with system default (or use pygame/playsound)
                import subprocess
                subprocess.run(["powershell", "-c", f"(New-Object Media.SoundPlayer '{f.name}').PlaySync()"],
                              capture_output=True, shell=False)

        asyncio.run(_speak())

    def run_push_to_talk(self, callback):
        """
        Run push-to-talk loop using pynput (no admin required).
        callback(text) is called with transcribed text when user releases hotkey
        """
        print(f"\n🎙️ Push-to-talk active. Hold F9 to speak, Escape to exit.\n")

        def on_press(key):
            if key == self.hotkey:
                self.start_recording()

        def on_release(key):
            if key == self.hotkey:
                text = self.stop_recording()
                if text:
                    callback(text)
            if key == keyboard.Key.esc:
                return False  # Stop listener

        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            listener.join()


# Example usage
if __name__ == "__main__":
    def on_transcription(text):
        if text:
            print(f"\n✅ You said: {text}\n")
            # Here you would send to Claude/Ollama and get response

    pipeline = VoicePipeline(
        whisper_model="base",  # Use "tiny" for faster but less accurate
        tts_voice="en-US-GuyNeural",  # Or "it-IT-DiegoNeural" for Italian
    )

    pipeline.run_push_to_talk(on_transcription)
```

### Step 2.4: Installa dipendenze voice

```powershell
pip install sounddevice pynput numpy edge-tts

# Test audio devices
python -c "import sounddevice as sd; print(sd.query_devices())"
```

### Step 2.5: Crea Simple Memory Store

Crea file `src/memory.py`:

```python
"""
Jarvis Simple Memory Store
SQLite-based conversation history and context
"""
import sqlite3
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

class JarvisMemory:
    def __init__(self, db_path: str = "jarvis_memory.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    metadata TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tool_calls (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    tool_name TEXT NOT NULL,
                    arguments TEXT,
                    result TEXT,
                    timestamp TEXT NOT NULL,
                    success INTEGER
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_tool_session ON tool_calls(session_id)
            """)

    def add_message(
        self,
        session_id: str,
        role: str,  # "user" or "assistant"
        content: str,
        metadata: Optional[Dict] = None
    ):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO conversations (session_id, role, content, timestamp, metadata) VALUES (?, ?, ?, ?, ?)",
                (session_id, role, content, datetime.now().isoformat(), json.dumps(metadata) if metadata else None)
            )

    def add_tool_call(
        self,
        session_id: str,
        tool_name: str,
        arguments: Dict,
        result: str,
        success: bool
    ):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO tool_calls (session_id, tool_name, arguments, result, timestamp, success) VALUES (?, ?, ?, ?, ?, ?)",
                (session_id, tool_name, json.dumps(arguments), result, datetime.now().isoformat(), int(success))
            )

    def get_conversation(self, session_id: str, limit: int = 50) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM conversations WHERE session_id = ? ORDER BY timestamp DESC LIMIT ?",
                (session_id, limit)
            ).fetchall()
            return [dict(row) for row in reversed(rows)]

    def get_recent_tool_calls(self, session_id: str, limit: int = 10) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM tool_calls WHERE session_id = ? ORDER BY timestamp DESC LIMIT ?",
                (session_id, limit)
            ).fetchall()
            return [dict(row) for row in rows]

    def search_conversations(self, query: str, limit: int = 20) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM conversations WHERE content LIKE ? ORDER BY timestamp DESC LIMIT ?",
                (f"%{query}%", limit)
            ).fetchall()
            return [dict(row) for row in rows]


# Example usage
if __name__ == "__main__":
    memory = JarvisMemory("data/jarvis_memory.db")

    # Add test data
    memory.add_message("test-session", "user", "What's the weather like?")
    memory.add_message("test-session", "assistant", "I don't have weather data access yet.")
    memory.add_tool_call("test-session", "list_directory", {"path": "."}, "[FILE] test.txt", True)

    # Retrieve
    print("Conversation:", memory.get_conversation("test-session"))
    print("Tool calls:", memory.get_recent_tool_calls("test-session"))
```

**Check di successo Day 2:**
- [ ] `python src/voice_pipeline.py` funziona (recording + transcription)
- [ ] Memory store salva e recupera dati
- [ ] Push-to-talk con Ctrl+Shift+J attiva registrazione

---

## Day 3: Hardening + Dashboard + Test

### Step 3.1: Crea Audit Logger

Crea file `src/audit.py`:

```python
"""
Jarvis Audit Logger
Tracks all actions for security and debugging
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

class AuditLogger:
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        # Setup file logging
        self.logger = logging.getLogger("jarvis.audit")
        self.logger.setLevel(logging.INFO)

        # Daily log file
        log_file = self.log_dir / f"audit_{datetime.now().strftime('%Y%m%d')}.log"
        handler = logging.FileHandler(log_file, encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s'
        ))
        self.logger.addHandler(handler)

        # Also log to console
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter('%(asctime)s | %(message)s'))
        self.logger.addHandler(console)

    def log_action(
        self,
        action: str,
        details: Dict[str, Any],
        success: bool = True,
        sensitive: bool = False
    ):
        """Log an action with details"""
        # Redact sensitive data
        if sensitive:
            details = {k: "[REDACTED]" if k in ["token", "password", "api_key", "secret"] else v
                      for k, v in details.items()}

        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "success": success,
            "details": details
        }

        level = logging.INFO if success else logging.WARNING
        self.logger.log(level, json.dumps(entry, ensure_ascii=False))

    def log_tool_call(
        self,
        tool_name: str,
        arguments: Dict,
        result: str,
        execution_time_ms: float,
        blocked: bool = False
    ):
        """Log MCP tool calls"""
        self.log_action(
            action=f"TOOL_CALL:{tool_name}",
            details={
                "arguments": arguments,
                "result_preview": result[:200] if len(result) > 200 else result,
                "execution_time_ms": execution_time_ms,
                "blocked": blocked
            },
            success=not blocked
        )

    def log_llm_request(
        self,
        provider: str,  # "claude" or "ollama"
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        latency_ms: float
    ):
        """Log LLM API calls"""
        self.log_action(
            action=f"LLM_REQUEST:{provider}",
            details={
                "model": model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "latency_ms": latency_ms
            }
        )

    def log_security_event(
        self,
        event_type: str,
        description: str,
        severity: str = "INFO"  # INFO, WARNING, CRITICAL
    ):
        """Log security-related events"""
        self.log_action(
            action=f"SECURITY:{event_type}",
            details={"description": description, "severity": severity},
            success=severity == "INFO"
        )


# Global instance
audit = AuditLogger()
```

### Step 3.2: Crea Dashboard Web Semplice

Crea file `src/dashboard.py`:

```python
"""
Jarvis Simple Web Dashboard
View status, logs, and stats
"""
from flask import Flask, render_template_string, jsonify
from pathlib import Path
import sqlite3
import json
from datetime import datetime, timedelta

app = Flask(__name__)

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Jarvis Dashboard</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 20px; background: #1a1a2e; color: #eee; }
        .card { background: #16213e; padding: 20px; margin: 10px 0; border-radius: 8px; }
        .status-ok { color: #00ff88; }
        .status-error { color: #ff4444; }
        h1 { color: #00ff88; }
        h2 { color: #4da8da; border-bottom: 1px solid #4da8da; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px; border-bottom: 1px solid #333; }
        .log-entry { font-family: monospace; font-size: 12px; margin: 5px 0; }
    </style>
</head>
<body>
    <h1>🤖 Jarvis Dashboard</h1>

    <div class="card">
        <h2>System Status</h2>
        <p>Claude Desktop: <span class="status-ok">● Connected</span></p>
        <p>Ollama: <span class="{{ 'status-ok' if ollama_status else 'status-error' }}">{{ '● Running' if ollama_status else '○ Offline' }}</span></p>
        <p>Voice Pipeline: <span class="status-ok">● Ready</span></p>
        <p>Last Activity: {{ last_activity }}</p>
    </div>

    <div class="card">
        <h2>Recent Tool Calls (Last 24h)</h2>
        <table>
            <tr><th>Time</th><th>Tool</th><th>Status</th></tr>
            {% for call in tool_calls %}
            <tr>
                <td>{{ call.timestamp }}</td>
                <td>{{ call.tool_name }}</td>
                <td class="{{ 'status-ok' if call.success else 'status-error' }}">
                    {{ 'OK' if call.success else 'BLOCKED' }}
                </td>
            </tr>
            {% endfor %}
        </table>
    </div>

    <div class="card">
        <h2>Recent Logs</h2>
        {% for log in logs %}
        <div class="log-entry">{{ log }}</div>
        {% endfor %}
    </div>
</body>
</html>
"""

def check_ollama():
    import subprocess
    try:
        result = subprocess.run(["ollama", "ps"], capture_output=True, timeout=5)
        return result.returncode == 0
    except:
        return False

def get_recent_tool_calls():
    db_path = Path("data/jarvis_memory.db")
    if not db_path.exists():
        return []

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        since = (datetime.now() - timedelta(hours=24)).isoformat()
        rows = conn.execute(
            "SELECT * FROM tool_calls WHERE timestamp > ? ORDER BY timestamp DESC LIMIT 20",
            (since,)
        ).fetchall()
        return [dict(row) for row in rows]

def get_recent_logs(limit=20):
    log_file = Path(f"logs/audit_{datetime.now().strftime('%Y%m%d')}.log")
    if not log_file.exists():
        return ["No logs today"]

    with open(log_file) as f:
        lines = f.readlines()
    return lines[-limit:]

@app.route("/")
def dashboard():
    return render_template_string(
        TEMPLATE,
        ollama_status=check_ollama(),
        last_activity=datetime.now().strftime("%H:%M:%S"),
        tool_calls=get_recent_tool_calls(),
        logs=get_recent_logs()
    )

@app.route("/api/status")
def api_status():
    return jsonify({
        "ollama": check_ollama(),
        "timestamp": datetime.now().isoformat()
    })

if __name__ == "__main__":
    print("🌐 Dashboard running at http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
```

### Step 3.3: Crea Script di Test

Crea file `tests/test_jarvis.py`:

```python
"""
Jarvis Integration Tests
Run: python -m pytest tests/test_jarvis.py -v
"""
import pytest
import subprocess
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

class TestOllamaSetup:
    def test_ollama_installed(self):
        """Ollama CLI is available"""
        result = subprocess.run(["ollama", "--version"], capture_output=True)
        assert result.returncode == 0

    def test_ollama_model_available(self):
        """Llama 3.1 model is downloaded"""
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        assert "llama3.1" in result.stdout.lower()

    def test_ollama_responds(self):
        """Ollama can generate a response"""
        result = subprocess.run(
            ["ollama", "run", "llama3.1:8b", "Say 'test ok' and nothing else"],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert "test" in result.stdout.lower() or "ok" in result.stdout.lower()


class TestVoicePipeline:
    def test_whisper_import(self):
        """faster-whisper is installed"""
        from faster_whisper import WhisperModel
        assert WhisperModel is not None

    def test_sounddevice_import(self):
        """sounddevice is installed"""
        import sounddevice as sd
        devices = sd.query_devices()
        assert len(devices) > 0


class TestMemory:
    def test_memory_store(self):
        """Memory store works"""
        from memory import JarvisMemory

        mem = JarvisMemory(":memory:")  # In-memory for test
        mem.add_message("test", "user", "Hello")
        conv = mem.get_conversation("test")
        assert len(conv) == 1
        assert conv[0]["content"] == "Hello"


class TestMCPServers:
    def test_filesystem_server_exists(self):
        """Filesystem MCP server file exists"""
        server_path = Path(__file__).parent.parent / "mcp_servers" / "filesystem_server.py"
        assert server_path.exists()

    def test_shell_server_exists(self):
        """Shell MCP server file exists"""
        server_path = Path(__file__).parent.parent / "mcp_servers" / "shell_server.py"
        assert server_path.exists()


class TestSecurity:
    def test_workspace_isolation(self):
        """Workspace path is properly isolated"""
        workspace = Path(os.environ.get("JARVIS_WORKSPACE", Path.home() / "jarvis" / "workspace"))
        # Ensure it's not root or system directory
        assert "Windows" not in str(workspace)
        assert "System32" not in str(workspace)

    def test_no_secrets_in_code(self):
        """No hardcoded secrets in source files"""
        src_dir = Path(__file__).parent.parent / "src"
        mcp_dir = Path(__file__).parent.parent / "mcp_servers"

        suspicious_patterns = ["api_key=", "password=", "secret=", "token="]

        for dir in [src_dir, mcp_dir]:
            if dir.exists():
                for py_file in dir.glob("*.py"):
                    content = py_file.read_text()
                    for pattern in suspicious_patterns:
                        # Skip if it's just checking for the pattern (like this test)
                        if f'"{pattern}"' in content or f"'{pattern}'" in content:
                            continue
                        assert pattern not in content, f"Possible secret in {py_file}: {pattern}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
```

### Step 3.4: Script di avvio completo

Crea file `start_jarvis.ps1`:

```powershell
# Jarvis Startup Script
# Run: .\start_jarvis.ps1

Write-Host "🤖 Starting Jarvis..." -ForegroundColor Green

# Activate venv
$venvPath = "$PSScriptRoot\.venv\Scripts\Activate.ps1"
if (Test-Path $venvPath) {
    . $venvPath
} else {
    Write-Host "Error: Virtual environment not found. Run setup first." -ForegroundColor Red
    exit 1
}

# Check Ollama
Write-Host "Checking Ollama..." -ForegroundColor Yellow
$ollama = Get-Process ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
    Write-Host "Starting Ollama..." -ForegroundColor Yellow
    Start-Process ollama -ArgumentList "serve" -WindowStyle Hidden
    Start-Sleep -Seconds 3
}

# Verify Ollama is responding
try {
    $response = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -TimeoutSec 5
    Write-Host "✓ Ollama is running" -ForegroundColor Green
} catch {
    Write-Host "⚠ Ollama not responding" -ForegroundColor Yellow
}

# Start Dashboard in background
Write-Host "Starting Dashboard..." -ForegroundColor Yellow
Start-Process python -ArgumentList "src/dashboard.py" -WindowStyle Hidden
Write-Host "✓ Dashboard at http://localhost:5000" -ForegroundColor Green

# Reminder for Claude Desktop
Write-Host "`n📌 REMINDER: Open Claude Desktop separately for MCP integration" -ForegroundColor Cyan

# Start voice pipeline (main thread)
Write-Host "`n🎙️ Starting Voice Pipeline (Ctrl+C to stop)..." -ForegroundColor Green
python src/voice_pipeline.py
```

**Check di successo Day 3:**
- [ ] `python -m pytest tests/ -v` → tutti i test passano
- [ ] Dashboard accessibile su http://localhost:5000
- [ ] Audit logs scritti in `logs/`
- [ ] `.\start_jarvis.ps1` avvia tutto correttamente

---

# 5. Tool Integrations

## 5.1 Claude Desktop/Code via MCP

### Architettura MCP

```
┌────────────────────────┐     stdio      ┌────────────────────┐
│    Claude Desktop      │◄──────────────►│   MCP Server 1     │
│    (MCP Host)          │                │  (filesystem)      │
│                        │                └────────────────────┘
│                        │     stdio      ┌────────────────────┐
│                        │◄──────────────►│   MCP Server 2     │
│                        │                │  (shell)           │
│                        │                └────────────────────┘
│                        │     stdio      ┌────────────────────┐
│                        │◄──────────────►│   MCP Server 3     │
└────────────────────────┘                │  (git)             │
                                          └────────────────────┘
```

### MCP Servers da creare

| Server | Tools esposti | Priorità |
|--------|---------------|----------|
| `jarvis-filesystem` | read_file, write_file, list_directory | V1 Core |
| `jarvis-shell` | run_safe_command | V1 Core |
| `jarvis-git` | status, diff, log, commit (con confirm) | V1 |
| `jarvis-notes` | search_notes, add_note, get_note | V2 |
| `jarvis-calendar` | get_events, add_event | V2 |
| `jarvis-n8n` | trigger_workflow, list_workflows | V2 |

### Esempio: Git MCP Server

```python
# mcp_servers/git_server.py
"""
Jarvis Git MCP Server
Git operations with safety checks
"""
import subprocess
from pathlib import Path
from mcp.server import Server
from mcp.types import Tool, TextContent

server = Server("jarvis-git")

ALLOWED_REPOS = [
    Path.home() / "jarvis" / "workspace",
    # Add other allowed repo paths
]

def is_safe_repo(path: str) -> bool:
    resolved = Path(path).resolve()
    return any(str(resolved).startswith(str(allowed)) for allowed in ALLOWED_REPOS)

def run_git(args: list, cwd: str) -> str:
    if not is_safe_repo(cwd):
        return f"Error: Repository not in allowed list"

    result = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=30
    )
    return result.stdout + result.stderr

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="git_status",
            description="Show git status of a repository",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_path": {"type": "string", "description": "Path to git repository"}
                },
                "required": ["repo_path"]
            }
        ),
        Tool(
            name="git_diff",
            description="Show git diff (unstaged changes)",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_path": {"type": "string"},
                    "staged": {"type": "boolean", "default": False}
                },
                "required": ["repo_path"]
            }
        ),
        Tool(
            name="git_log",
            description="Show recent commits",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_path": {"type": "string"},
                    "count": {"type": "integer", "default": 10}
                },
                "required": ["repo_path"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    repo = arguments.get("repo_path", ".")

    if name == "git_status":
        output = run_git(["status", "-sb"], repo)
    elif name == "git_diff":
        args = ["diff", "--staged"] if arguments.get("staged") else ["diff"]
        output = run_git(args, repo)
    elif name == "git_log":
        count = arguments.get("count", 10)
        output = run_git(["log", f"-{count}", "--oneline", "--graph"], repo)
    else:
        output = f"Unknown tool: {name}"

    return [TextContent(type="text", text=output)]

if __name__ == "__main__":
    import asyncio
    from mcp.server.stdio import stdio_server

    async def main():
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    asyncio.run(main())
```

## 5.2 GitHub Integration

Aggiungi a shell allowlist:
```python
ALLOWED_COMMANDS = {
    # ... existing ...
    "gh": ["pr", "issue", "repo", "workflow"],  # GitHub CLI
}
```

## 5.3 n8n Integration

```python
# mcp_servers/n8n_server.py
"""
Jarvis n8n MCP Server
Trigger workflows via webhook
"""
import httpx
from mcp.server import Server
from mcp.types import Tool, TextContent

server = Server("jarvis-n8n")

N8N_BASE_URL = "http://localhost:5678"  # Default n8n URL

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="trigger_workflow",
            description="Trigger an n8n workflow via webhook",
            inputSchema={
                "type": "object",
                "properties": {
                    "webhook_path": {"type": "string", "description": "Webhook path (e.g., /webhook/my-flow)"},
                    "data": {"type": "object", "description": "JSON data to send"}
                },
                "required": ["webhook_path"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "trigger_workflow":
        url = f"{N8N_BASE_URL}{arguments['webhook_path']}"
        data = arguments.get("data", {})

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(url, json=data, timeout=30)
                return [TextContent(type="text", text=f"Triggered: {response.status_code}\n{response.text[:500]}")]
            except Exception as e:
                return [TextContent(type="text", text=f"Error: {str(e)}")]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]
```

## 5.4 Obsidian Notes Integration

```python
# mcp_servers/notes_server.py
"""
Jarvis Notes MCP Server
Search and manage Obsidian/Markdown notes
"""
import re
from pathlib import Path
from mcp.server import Server
from mcp.types import Tool, TextContent

server = Server("jarvis-notes")

NOTES_DIR = Path.home() / "Documents" / "Obsidian"  # Adjust path

@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="search_notes",
            description="Search notes by keyword",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "limit": {"type": "integer", "default": 10}
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="get_note",
            description="Get content of a specific note",
            inputSchema={
                "type": "object",
                "properties": {
                    "filename": {"type": "string"}
                },
                "required": ["filename"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "search_notes":
        query = arguments["query"].lower()
        limit = arguments.get("limit", 10)
        results = []

        for md_file in NOTES_DIR.rglob("*.md"):
            try:
                content = md_file.read_text(encoding="utf-8")
                if query in content.lower():
                    # Extract snippet around match
                    idx = content.lower().find(query)
                    snippet = content[max(0, idx-50):idx+100]
                    results.append(f"📄 {md_file.name}\n   ...{snippet}...")
                    if len(results) >= limit:
                        break
            except:
                continue

        return [TextContent(type="text", text="\n\n".join(results) if results else "No matches found")]

    elif name == "get_note":
        filename = arguments["filename"]
        # Security: only allow files in NOTES_DIR
        file_path = (NOTES_DIR / filename).resolve()
        if not str(file_path).startswith(str(NOTES_DIR)):
            return [TextContent(type="text", text="Error: Access denied")]

        if file_path.exists():
            return [TextContent(type="text", text=file_path.read_text(encoding="utf-8"))]
        else:
            return [TextContent(type="text", text=f"Note not found: {filename}")]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]
```

---

# 6. Bottleneck Report + Review Panel

## 6.1 Colli di Bottiglia Identificati

| # | Bottleneck | Severity | Causa | Mitigazione |
|---|------------|----------|-------|-------------|
| 1 | **STT Latenza** | Alta | Whisper non è streaming nativo | Usare faster-whisper con VAD, chunking 2-3s |
| 2 | **TTS Qualità IT** | Media | Piper voci IT limitate | Usare modello riccardo-medium, o Coqui |
| 3 | **MCP Startup** | Media | Ogni server è processo separato | Pre-warm servers, persistent connections |
| 4 | **Claude Rate Limits** | Media | Subscription ha limiti | Caching, fallback Ollama, batch requests |
| 5 | **GPU Memory** | Alta (Pro tier) | LLM + Whisper competono | Whisper su CPU, LLM su GPU, o scheduling |
| 6 | **Network Dependency** | Media | Claude richiede internet | Offline-first design con sync |
| 7 | **Audio Device Lock** | Bassa | Mic/speaker esclusivi | sounddevice stream management |

## 6.2 Test Plan

### Test Funzionali
```bash
# 1. Test STT latenza
python -c "
import time
from faster_whisper import WhisperModel
model = WhisperModel('base')
start = time.time()
segments, _ = model.transcribe('test.wav')
list(segments)
print(f'STT latency: {(time.time()-start)*1000:.0f}ms')
"

# 2. Test TTS qualità
python -c "
from piper import PiperVoice
voice = PiperVoice.load('models/piper/it_IT-riccardo-medium.onnx')
audio = voice.synthesize('Ciao, sono Jarvis, il tuo assistente.')
# Play and subjectively evaluate
"

# 3. Test MCP roundtrip
# In Claude Desktop, time a simple tool call
```

### Test Carico
```bash
# Stress test Ollama
ollama run llama3.1:8b "Generate 500 words about AI" --verbose

# Memory monitoring
python -c "
import psutil
import time
while True:
    mem = psutil.virtual_memory()
    print(f'RAM: {mem.percent}% | Available: {mem.available/1e9:.1f}GB')
    time.sleep(5)
"
```

## 6.3 Security Checklist

### Authentication & Authorization
- [ ] MCP servers running as non-root user
- [ ] Workspace directory has restricted permissions
- [ ] No hardcoded credentials in source code
- [ ] Environment variables for secrets (`.env` file with `chmod 600`)

### Network Security
- [ ] Ollama bound to localhost only
- [ ] Dashboard not exposed to internet
- [ ] WebSocket connections require auth token (V2)
- [ ] HTTPS for any external APIs

### Data Protection
- [ ] Audit logs don't contain PII/secrets
- [ ] Voice recordings are ephemeral (not persisted)
- [ ] Memory DB has restricted file permissions
- [ ] Git credentials managed via credential helper, not stored

### Tool Execution Safety
- [ ] Shell commands have strict allowlist
- [ ] Filesystem access limited to workspace
- [ ] Write operations require double-confirm
- [ ] Command injection patterns blocked

### Privacy
- [ ] Push-to-talk (no always-listening)
- [ ] Visual indicator when recording
- [ ] Camera off by default (V2)
- [ ] Local-first processing preference

---

# 7. Verification Commands

Run these commands after installation to verify everything is working:

```powershell
# 1. Check Python version (need 3.10+)
python --version

# 2. Verify MCP installation
python -c "from mcp.server import Server; print('MCP OK')"

# 3. Verify faster-whisper
python -c "from faster_whisper import WhisperModel; print('Whisper OK')"

# 4. Verify edge-tts (TTS)
python -c "import edge_tts; print('edge-tts OK')"

# 5. Verify pynput (hotkey handling - no admin required)
python -c "from pynput import keyboard; print('pynput OK')"

# 6. Verify sounddevice (audio I/O)
python -c "import sounddevice as sd; print(f'Audio devices: {len(sd.query_devices())} found')"

# 7. Test Ollama connection
ollama list

# 8. Test MCP filesystem server (should start without errors)
python mcp_servers/filesystem_server.py --help 2>&1 || python mcp_servers/filesystem_server.py

# 9. Run unit tests (if available)
python -m pytest tests/ -v
```

**Expected Results:**
- All "OK" messages appear
- No import errors
- Ollama shows installed models
- MCP server starts without exceptions

**Troubleshooting:**
- If MCP fails: `pip install mcp pywin32`
- If audio fails: Check device in Sound settings
- If Ollama fails: Run `ollama serve` in background first

---

# 8. Sources & Links

## Official Documentation
| Resource | URL |
|----------|-----|
| MCP Specification | https://modelcontextprotocol.io/specification/2025-11-25 |
| Claude Desktop MCP | https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop |
| Claude Code MCP | https://code.claude.com/docs/en/mcp |
| Ollama Documentation | https://docs.ollama.com |
| faster-whisper | https://github.com/SYSTRAN/faster-whisper |
| Piper TTS | https://github.com/rhasspy/piper |
| Open Duck Mini | https://github.com/apirrone/Open_Duck_Mini |

## Hardware Vendors (EU)
| Vendor | Products | Link |
|--------|----------|------|
| Amazon.it | Everything | https://amazon.it |
| Melopero | Raspberry Pi, sensors | https://melopero.com |
| Beelink Official | Mini PCs | https://www.bee-link.com |
| RØDE | Microphones | https://rode.com |
| Logitech | Webcams | https://logitech.com |

## Technical References
| Topic | Resource |
|-------|----------|
| MCP Tutorial | https://mcpdirectory.app/blog/how-to-create-custom-mcp-server |
| Ollama Tool Calling | https://collabnix.com/best-ollama-models-for-function-calling-tools-complete-guide-2025 |
| Whisper Streaming | https://github.com/ufal/whisper_streaming |
| Piper Italian Voices | https://huggingface.co/kirys79/piper_italiano |
| Docker MCP Toolkit | https://www.docker.com/blog/connect-mcp-servers-to-claude-desktop-with-mcp-toolkit |

## Community & Support
| Resource | Link |
|----------|------|
| Open Duck Mini Discord | https://discord.gg/UtJZsgfQGe |
| MCP GitHub | https://github.com/modelcontextprotocol |
| Ollama Discord | https://discord.gg/ollama |

---

# Appendix: Quick Reference Card

```
┌─────────────────────────────────────────────────────────────────┐
│                    JARVIS QUICK REFERENCE                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  🎙️  VOICE                                                      │
│  ───────────                                                    │
│  Push-to-talk: Ctrl+Shift+J                                    │
│  Cancel recording: Escape                                       │
│                                                                 │
│  🛠️  TOOLS (in Claude Desktop)                                  │
│  ────────────────────────────                                   │
│  - "List files in workspace"                                    │
│  - "Read file X in workspace"                                   │
│  - "Git status of [repo]"                                       │
│  - "Run git diff"                                               │
│                                                                 │
│  📊  DASHBOARD                                                  │
│  ──────────                                                     │
│  URL: http://localhost:5000                                     │
│                                                                 │
│  🔧  COMMANDS                                                   │
│  ──────────                                                     │
│  Start:    .\start_jarvis.ps1                                  │
│  Test:     python -m pytest tests/ -v                          │
│  Logs:     Get-Content logs\audit_*.log -Tail 50               │
│                                                                 │
│  ⚠️  TROUBLESHOOTING                                            │
│  ─────────────────                                              │
│  MCP not working: Restart Claude Desktop                        │
│  Ollama slow: Check RAM usage, reduce model size               │
│  No audio: Check sounddevice.query_devices()                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

**Document Version**: 1.0
**Last Updated**: 2025-01-10
**Author**: Claude (Jarvis Build Guide Generator)
